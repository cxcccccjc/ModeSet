"""V10: targeted continuous/temporal alternatives, no inherited safety claims."""
from pathlib import Path
import sys
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'v9'))
from candidates import Candidate

def warm_pairs(y,audits,refs,warm,delay):
    return [(t,int(j),y[t,j].copy(),float(refs[t,j])) for t in range(warm) if t+delay<=warm for j in np.flatnonzero(audits[t])]

class Ridge:
    def __init__(self,n,forget=.99,theta=None):
        self.theta=np.zeros(n) if theta is None else np.array(theta,float);self.P=np.eye(n);self.forget=forget
    def update(self,z,v):
        P=self.P/self.forget;u=P@z;k=u/(1+z@u)
        self.theta+=k*(v-self.theta@z);self.P=P-np.outer(k,u);self.P=(self.P+self.P.T)/2

class WarmLegacy:
    def __init__(self,name,cal,c,p,seed=0,**params):
        self.inner=Candidate('Legacy:JointRLS' if name=='WarmJoint' else 'Legacy:RLS',cal,c,p,seed,**params);self.base=None
    def initialize_history(self,y,audits,refs,warm,delay):
        for t,j,yy,v in warm_pairs(y,audits,refs,warm,delay):
            _,packet=self.inner.predict(y[t]);mask=np.zeros(y.shape[1],bool);mask[j]=True
            self.inner.audit(t,packet,refs[t],mask)
    def predict(self,*a,**kw):return self.inner.predict(*a,**kw)
    def audit(self,*a,**kw):return self.inner.audit(*a,**kw)

class ModeAdapt:
    def __init__(self,name,cal,c,p,seed=0,**params):
        self.name=name;self.c=c;self.base=None;self.params=params
        self.mode=Candidate('ModeSet',cal,c,p,seed,threshold=4.,coverage=.875,width=2.)
        self.joint=Candidate('Legacy:JointRLS',cal,c,p,seed,forget=params.get('forget',.99))
        self.reg=Ridge(c.N+1,params.get('forget',.99),np.r_[np.full(c.N,1/c.N),0.])
    def initialize_history(self,y,audits,refs,warm,delay):
        self.mode.initialize_history(y,audits,refs,warm,delay)
        for t,j,yy,v in warm_pairs(y,audits,refs,warm,delay):
            _,mp=self.mode.predict(y[t]);_,jp=self.joint.predict(y[t]);mask=np.zeros(self.c.J,bool);mask[j]=True
            self.joint.audit(t,jp,refs[t],mask)
            self.reg.update(np.r_[mp['z'][j],1.],v)
    def predict(self,y,commit=False,t=None):
        out,mp=self.mode.predict(y,commit=commit,t=t);jo,jp=self.joint.predict(y,commit=commit,t=t)
        estimate=jo if self.name=='ModeClip' else np.c_[mp['z'],np.ones(self.c.J)]@self.reg.theta
        interval=mp['intervals'];ok=np.isfinite(interval).all(axis=1)
        if self.name=='ModeClip' or self.params.get('clip',False):estimate=np.where(ok,np.clip(estimate,interval[:,0],interval[:,1]),estimate)
        packet={**mp,'out':estimate.copy(),'mode_packet':mp,'joint_packet':jp,'joint_out':jo.copy(),'midpoint_out':out.copy()}
        return estimate,packet
    def audit(self,t,packet,v,mask):
        self.mode.audit(t,packet['mode_packet'],v,mask);self.joint.audit(t,packet['joint_packet'],v,mask)
        for j in np.flatnonzero(mask):self.reg.update(np.r_[packet['mode_packet']['z'][j],1.],v[j])

class ContrastModel:
    """Direct supervised common-error regression on source contrasts.

    xhat = mean(y) + g(y-mean(y), past returned references).
    RFF/linear/temporal kernel are separate alternatives, not a stacked model.
    """
    def __init__(self,name,cal,c,p,seed=0,**params):
        self.name=name;self.c=c;self.base=None;self.params=params;self.seq=0
        self.scale=np.maximum(.06,1.4826*np.median(abs(cal-np.median(cal,axis=0)),axis=0))*np.sqrt(c.N)
        self.width=float(params.get('width',1.));self.rff=32 if name=='ContrastRFF' else 0
        rng=np.random.default_rng(51001);self.omega=rng.normal(size=(c.N,self.rff))/self.width;self.phase=rng.uniform(0,2*np.pi,self.rff)
        self.reg=Ridge(c.N+1+self.rff,params.get('forget',.99));self.bank=[]
    def contrasts(self,y):return (y-y.mean(axis=-1,keepdims=True))/self.scale
    def features(self,y):
        z=self.contrasts(y);a=[z]
        if self.rff:a.append(np.sqrt(2/self.rff)*np.cos(z@self.omega+self.phase))
        a.append(np.ones((*z.shape[:-1],1)));return np.concatenate(a,axis=-1)
    def observe(self,y,v,t):
        if self.name=='TimeKernel':
            self.bank.append((self.contrasts(y),float(v-y.mean()),int(t)));self.bank=self.bank[-256:]
        else:self.reg.update(self.features(y),v-y.mean())
    def initialize_history(self,y,audits,refs,warm,delay):
        for t,j,yy,v in warm_pairs(y,audits,refs,warm,delay):self.observe(yy,v,t)
        self.seq=warm
    def predict(self,y,commit=False,t=None):
        if t is None:t=self.seq
        center=y.mean(axis=1)
        if self.name=='TimeKernel':
            if not self.bank:out=center.copy()
            else:
                z=np.array([b[0] for b in self.bank]);target=np.array([b[1] for b in self.bank]);age=t-np.array([b[2] for b in self.bank])
                logw=-np.sum((self.contrasts(y)[:,None,:]-z[None,:,:])**2,axis=2)/(2*self.width**2)-age[None,:]/self.params.get('tau',64.)
                logw-=logw.max(axis=1,keepdims=True);w=np.exp(logw);w/=w.sum(axis=1,keepdims=True);out=center+w@target
        else:out=center+self.features(y)@self.reg.theta
        if commit:self.seq=t+1
        return out,dict(y=y.copy(),out=out.copy(),z=y.copy(),w=np.full_like(y,1/self.c.N),q=np.ones(self.c.N))
    def audit(self,t,packet,v,mask):
        for j in np.flatnonzero(mask):self.observe(packet['y'][j],v[j],t)

def factory(name,cal,c,p,seed=0,**params):
    if name in ['WarmJoint','WarmRLS']:return WarmLegacy(name,cal,c,p,seed,**params)
    if name in ['ModeClip','ModeRegression']:return ModeAdapt(name,cal,c,p,seed,**params)
    if name in ['ContrastLinear','ContrastRFF','TimeKernel']:return ContrastModel(name,cal,c,p,seed,**params)
    return Candidate(name,cal,c,p,seed,**params)
