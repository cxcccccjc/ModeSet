"""A single local inverse regression; conventional estimator, novelty not claimed."""
import numpy as np
from models import warm_pairs

class LocalJoint:
    def __init__(self,name,cal,c,p,seed=0,**params):
        self.name=name;self.c=c;self.base=None;self.params=params;self.seq=0;self.bank=[]
        self.contrast_scale=np.maximum(.06,1.4826*np.median(abs(cal-np.median(cal,axis=0)),axis=0))*np.sqrt(c.N)
        self.reg_scale=np.ones(c.N)
    def initialize_history(self,y,audits,refs,warm,delay):
        pairs=warm_pairs(y,audits,refs,warm,delay)
        self.reg_scale=np.maximum(.1,np.std(np.array([q[2] for q in pairs]),axis=0))
        for t,j,yy,v in pairs:self.bank.append((yy,v-float(yy.mean()),t))
        self.bank=self.bank[-256:];self.seq=warm
    def predict(self,y,commit=False,t=None):
        if t is None:t=self.seq
        center=y.mean(axis=1)
        if not self.bank:out=center.copy()
        else:
            Y=np.array([b[0] for b in self.bank]);target=np.array([b[1] for b in self.bank]);age=t-np.array([b[2] for b in self.bank])
            z=(Y-Y.mean(axis=1,keepdims=True))/self.contrast_scale
            out=[]
            for yy,mean in zip(y,center):
                query=(yy-mean)/self.contrast_scale
                lw=-np.sum((z-query)**2,axis=1)/(2*self.params.get('width',1.)**2)-age/self.params.get('tau',64.)
                w=np.exp(lw-lw.max());w/=w.sum()
                # Query-centered local linear correction; intercept is weakly regularized.
                X=np.c_[np.ones(len(Y)),(Y-yy)/self.reg_scale]
                G=X.T@(w[:,None]*X)+np.diag(np.r_[.001,np.full(self.c.N,.1)])
                beta=np.linalg.solve(G,X.T@(w*target))
                out.append(mean+beta[0])
            out=np.array(out)
        if commit:self.seq=t+1
        return out,dict(y=y.copy(),out=out.copy(),z=y.copy(),w=np.full_like(y,1/self.c.N),q=np.ones(self.c.N))
    def audit(self,t,packet,v,mask):
        for j in np.flatnonzero(mask):self.bank.append((packet['y'][j].copy(),float(v[j]-packet['y'][j].mean()),int(t)))
        self.bank=self.bank[-256:]
