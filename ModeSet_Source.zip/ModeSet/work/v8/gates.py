"""V8 finite-audit-design envelope. Known statistical primitives, new pilot.

No labels, correctness claims, or attack labels enter admission decisions.
"""
import itertools
import numpy as np

def loss(r,tau=.5):
    a=np.abs(r);return np.where(a<=tau,a*a,2*tau*a-tau*tau)

def logsumexp(a,axis=-1):
    m=np.max(a,axis=axis,keepdims=True)
    return np.squeeze(m+np.log(np.sum(np.exp(a-m),axis=axis,keepdims=True)),axis=axis)

class DesignGate:
    def __init__(self,J,p,e=0.,alpha=.05,horizon=1000,window=None,kind='exact'):
        assert 0<p<=1 and J>=1 and 0<alpha<1
        self.J=J;self.p=p;self.e=e;self.alpha=alpha;self.T=horizon;self.window=window;self.kind=kind
        self.lams=2.**np.arange(-12,9);self.K=len(self.lams)
        self.signs=np.array(list(itertools.product([-1.,1.],repeat=J)))
        self.states=[self.state(-1,alpha if window is None else alpha/2)]
        self.records={};self.steps=0;self.last_fraction=1.;self.B=0.;self.last_observed=None
    def state(self,start,alpha):
        return dict(start=start,penalty=np.log(self.K/alpha),ledger=0.,pending=0.,score=0.,psi=np.zeros(self.K),ref=0.,nonzero=False)
    def cumulant(self,c):
        if np.max(c)==0:return np.zeros(self.K)
        if self.kind=='hoeffding':return .5*(self.J*np.max(c)/self.p*self.lams)**2
        d=self.signs*c[None,:]
        # log E exp(lambda * (sum D - I J/p D_selected)), max over box vertices.
        a=-self.lams[:,None,None]*(self.J/self.p)*d[None,:,:]
        lsample=np.log(self.p/self.J)+logsumexp(a,axis=2)
        lmix=lsample if self.p==1 else np.logaddexp(np.log1p(-self.p),lsample)
        return np.maximum(0.,np.max(self.lams[:,None]*d.sum(axis=1)[None,:]+lmix,axis=1))
    def fraction(self,m,g):
        cost=float(np.sum(np.abs(g-m)))
        if cost==0:return 1.
        t=self.steps
        avail=2*np.sqrt(t+1)-self.states[0]['ledger']
        if self.window:
            for s in self.states[1:]:
                if t-s['start']<self.window:
                    avail=min(avail,2*np.sqrt(t-s['start']+1)-s['ledger'])
            avail=min(avail,2.) # New one-step interval.
        return float(np.clip(avail/cost,0,1))
    def propose(self,t,m,g):
        assert self.steps<self.T and t not in self.records
        b=self.fraction(m,g);u=self.steps
        if self.window:
            self.states=[self.states[0]]+[s for s in self.states[1:] if u-s['start']<self.window]
            self.states.append(self.state(u,self.alpha/(2*self.T)))
        self.steps+=1;self.B=2*np.sqrt(self.steps)
        out=m+b*(g-m);c=np.abs(out-m);cost=float(c.sum())
        for s in self.states:s['ledger']+=cost;s['pending']+=cost
        self.records[t]=(u,m.copy(),out.copy(),c)
        self.last_fraction=b
        return out
    def observe(self,t,v,mask):
        assert np.sum(mask)<=1 and t==min(self.records)
        assert self.last_observed is None or t>self.last_observed
        self.last_observed=t
        u,m,out,c=self.records.pop(t);cost=float(c.sum())
        z=self.J/self.p*float(np.sum(loss(out[mask]-v[mask])-loss(m[mask]-v[mask])))
        psi=self.cumulant(c);ref=2*self.e*cost
        for s in self.states:
            if s['start']>u:continue
            s['pending']=max(0.,s['pending']-cost);s['score']+=z;s['psi']+=psi;s['ref']+=ref
            s['nonzero']|=cost>0
            upper=s['score']+float(np.min((s['penalty']+s['psi'])/self.lams))+s['ref'] if s['nonzero'] else 0.
            s['ledger']=min(s['ledger'],upper+s['pending'])
