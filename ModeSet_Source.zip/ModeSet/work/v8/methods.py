import numpy as np
from gates import DesignGate,loss

def median_weights(y,G):
    J,N=y.shape;gsize=N//G;w=np.zeros((J,N))
    for j in range(J):
        blocks=y[j].reshape(G,gsize);meds=np.median(blocks,axis=1)
        gids=np.argsort(meds)[[(G-1)//2,G//2]]
        for g in gids:
            ids=np.argsort(blocks[g])[[(gsize-1)//2,gsize//2]]
            for i in ids:w[j,g*gsize+i]+=.25
    return w

class SourceModel:
    def __init__(self,cal,kind='gain'):
        self.kind=kind;self.N=cal.shape[1];self.rate=.1
        self.var=np.maximum(.003,np.mean(cal**2,axis=0));self.bias=cal.mean(axis=0)
        self.num=np.zeros(self.N);self.den=np.full(self.N,.01);self.q=self.var.copy()
        self.theta=np.column_stack([np.ones(self.N),-self.bias]);self.P=np.tile(np.eye(2),(self.N,1,1))
        if kind=='rls':self.q=np.maximum(.003,np.var(cal,axis=0))
        self.temp=np.zeros(self.N,bool);self.good=np.zeros(self.N,int);self.q99=np.max(abs(cal),axis=0)
    def predict(self,y):
        if self.kind=='rls':z=y*self.theta[:,0]+self.theta[:,1];extra=z.copy()
        elif self.kind=='gain':
            a=np.clip(self.num/np.maximum(self.den,.003),0,1);z=y-a*self.bias;extra=(self.bias.copy(),a.copy())
        else:z=y.copy();extra=None
        q=self.q if self.kind in ('gain','rls') else self.var
        w=1/q
        if self.kind=='reject':w*=~self.temp
        if w.sum()==0:w=np.ones(self.N)
        w=w/w.sum()
        return z,w,extra,q.copy()
    def audit(self,y,v,extra):
        r=y-v;eta=self.rate
        if self.kind=='gain':
            f,a=extra;self.num=(1-eta)*self.num+eta*r*f;self.den=(1-eta)*self.den+eta*f*f
            self.q=(1-eta)*self.q+eta*np.clip((r-a*f)**2,.003,4.)
        elif self.kind=='rls':
            X=np.column_stack([y,np.ones(self.N)]);P=self.P/.99;PX=np.einsum('nij,nj->ni',P,X)
            K=PX/(1+np.einsum('ni,ni->n',X,PX))[:,None]
            self.theta+=K*(v-np.einsum('ni,ni->n',self.theta,X))[:,None]
            self.P=P-np.einsum('ni,nj->nij',K,PX)
            self.q=(1-eta)*self.q+eta*np.clip((extra-v)**2,.003,4.)
        self.bias=(1-eta)*self.bias+eta*r;self.var=(1-eta)*self.var+eta*np.clip(r*r,.003,4.)
        bad=abs(r)>self.q99;self.temp|=bad;self.good=np.where(bad,0,self.good+1);self.temp[self.good>=3]=False

def crh(y,rep=None,power=2,max_iter=100,tol=1e-6,initial=None):
    J,N=y.shape;truth=np.mean(y,axis=1) if initial is None else np.array(initial,float)
    for k in range(max_iter):
        dist=np.maximum(np.sum(abs(y-truth[:,None])**power,axis=0),1e-12)
        w=np.log(np.sum(dist)/dist)
        if rep is not None:w*=rep
        w=w/w.sum();new=y@w
        if np.max(abs(new-truth))<tol:return new,np.broadcast_to(w,y.shape).copy(),k+1
        truth=new
    return truth,np.broadcast_to(w,y.shape).copy(),max_iter

class Method:
    def __init__(self,name,cal,c,p,seed=0):
        self.name=name;self.c=c;self.p=p;self.last_b=1.;self.gate=None;self.localgates=None;self.t=0
        self.mode='rls' if 'RLS' in name else 'reject' if name=='TempReject' else 'audit' if name=='AuditEWMA' else 'gain'
        self.model=SourceModel(cal,self.mode);self.alpha=np.ones(c.N);self.beta=np.ones(c.N)
        # Gamma has no unique numerical value in supplied TMC text. This is a declared adaptation.
        self.gamma=float(max(.05,np.quantile(abs(cal),.8)))
        if name.startswith(('Sqrt','Exact','Window')):
            self.gate=DesignGate(c.J,p,c.reference_error,horizon=c.T,kind='hoeffding' if name.startswith('Sqrt') else 'exact',window=64 if name.startswith('Window') else None)
        if name.startswith('LocalSafe'):
            self.localgates=[DesignGate(c.J,p,c.reference_error,alpha=.05/c.N,horizon=c.T) for _ in range(c.N)]
        self.jtheta=np.zeros(c.N+1);self.jtheta[:-1]=1/c.N;self.jP=np.eye(c.N+1)
        self.rng=np.random.default_rng(seed+101);self.initial=self.rng.normal(size=c.J)
    def predict(self,y,commit=False,t=None):
        J,N=y.shape;mw=median_weights(y,self.c.G);m=np.sum(mw*y,axis=1)
        extras=[];qs=[];zs=[];ws=[]
        if self.name=='GroupMedian':z=y.copy();w=mw.copy();g=m.copy();q=np.ones(N);extras=[None]*J
        elif self.name=='TDSC_CRH_core':
            g,w,_=crh(y,initial=self.initial);z=y.copy();q=np.ones(N);extras=[None]*J
        elif self.name.startswith('RDPP_'):
            g=np.empty(J);w=np.zeros_like(y);z=y.copy();q=self.alpha/(self.alpha+self.beta);extras=[None]*J
            for j in range(J):g[j:j+1],w[j:j+1],_=crh(y[j:j+1],rep=q,power=1 if self.name=='RDPP_abs' else 2)
        elif self.name=='JointRLS':
            g=np.column_stack([y,np.ones(J)])@self.jtheta;z=y.copy();w=np.broadcast_to(self.jtheta[:-1],y.shape).copy();q=np.ones(N);extras=[None]*J
        else:
            for j in range(J):
                z,w,ex,q=self.model.predict(y[j]);zs.append(z);ws.append(w);extras.append(ex);qs.append(q)
            z=np.array(zs);w=np.array(ws);q=np.array(qs).mean(axis=0)
            if self.localgates:
                for i,lg in enumerate(self.localgates):
                    if commit:z[:,i]=lg.propose(t,y[:,i],z[:,i])
                    else:z[:,i]=y[:,i]+lg.fraction(y[:,i],z[:,i])*(z[:,i]-y[:,i])
            g=np.sum(z*w,axis=1)
            if self.name=='TempReject' and self.model.temp.all():w=mw.copy();g=m.copy()
            if self.name=='CalCRH_RLS':g,w,_=crh(z,initial=self.initial)
            if self.name=='CalRDPP_RLS':
                rep=self.alpha/(self.alpha+self.beta)
                for j in range(J):g[j:j+1],w[j:j+1],_=crh(z[j:j+1],rep=rep,power=1)
        if self.gate:
            b=self.gate.fraction(m,g)
            out=self.gate.propose(t,m,g) if commit else m+b*(g-m)
        else:b=1.;out=g
        effw=b*w+(1-b)*mw
        packet=dict(y=y.copy(),z=z.copy(),w=w.copy(),q=q.copy(),m=m.copy(),out=out.copy(),extras=extras,b=b,effw=effw)
        if commit:
            self.last_b=b;self.t+=1
            if self.name.startswith('RDPP_'):
                good=abs(y-out[:,None])<=self.gamma
                self.alpha+=good.sum(axis=0);self.beta+=(~good).sum(axis=0)
            if self.name=='CalRDPP_RLS':
                good=abs(z-out[:,None])<=self.gamma
                self.alpha+=good.sum(axis=0);self.beta+=(~good).sum(axis=0)
        return out,packet
    def audit(self,t,packet,v,mask):
        if self.gate:self.gate.observe(t,v,mask)
        if self.localgates:
            for lg in self.localgates:lg.observe(t,v,mask)
        if self.name.startswith('RDPP_') or self.name in ('TDSC_CRH_core','GroupMedian'):return
        for j in np.flatnonzero(mask):
            y=packet['y'][j]
            if self.name=='JointRLS':
                X=np.r_[y,1.];P=self.jP/.99;PX=P@X;K=PX/(1+X@PX)
                self.jtheta+=K*(v[j]-X@self.jtheta);self.jP=P-np.outer(K,PX)
            else:self.model.audit(y,v[j],packet['extras'][j])
