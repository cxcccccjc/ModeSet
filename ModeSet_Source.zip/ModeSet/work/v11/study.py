from pathlib import Path
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1');os.environ.setdefault('OMP_NUM_THREADS','1')
import sys,json,argparse,hashlib,shutil,time,pickle,copy
from types import SimpleNamespace
from concurrent.futures import ProcessPoolExecutor,as_completed
import numpy as np
BASE=Path(__file__).resolve().parent;sys.path.insert(0,str(BASE.parent/'v10'));sys.path.insert(0,str(BASE.parent/'v9'))
from candidates import Candidate
from temporal_baselines import TemporalBaseline
from models import factory as legacy
from local_model import LocalJoint
from core import BoxMode,confusion_radius
from data import make

def construct(name,cal,c,params,seed):
    if name.startswith('Box'):return BoxMode(name,cal,c,.25,seed,**params)
    if name=='AuditTV':return TemporalBaseline(name,cal,c,.25,seed,**params)
    if name=='LocalJoint':return LocalJoint(name,cal,c,.25,seed,**params)
    return legacy(name,cal,c,.25,seed,**params)

def run(job,trace=False):
    case,seed,name,params=job;d=make(seed,**case);N=d['N'];c=SimpleNamespace(N=N,J=1,G=N,warm=d['warm'],T=d['T'],delay=d['delay'],reference_error=d['reference_error'])
    ids=[t for t in range(c.warm) if d['audit'][t] and t+c.delay<=c.warm];cal=d['y'][ids]-d['ref'][ids,None]
    model=construct(name,cal,c,params,seed);model.initialize_history(d['y'][:c.warm,None,:],d['audit'][:,None],d['ref'][:,None],c.warm,c.delay)
    pending=[];errors=[];ivs=[];fullcover=[];source_miss=[];components=[];switch=[];safecover=[];warmstats=None;startclock=time.perf_counter()
    for t in range(c.warm,len(d['x'])):
        for ot,packet in pending:
            if ot+c.delay==t:model.audit(ot,packet,np.array([d['ref'][ot]]),np.array([d['audit'][ot]]))
        pending=[a for a in pending if a[0]+c.delay>t]
        y=d['y'][t,None,:];out,packet=model.predict(y,commit=True,t=t);pending.append((t,packet))
        if t==d['start'] and name.startswith('Box'):
            warmstats=dict(mode_counts=[len(b) for b in model.boxes],confusion_diameter=confusion_radius(model.boxes,model.sigma,model.r),r=model.r,joint_templates=len(model.patterns),multiple_matches=model.multiple_matches,boxes=copy.deepcopy(model.boxes),sigma=model.sigma.tolist())
        if t<d['start']:continue
        errors.append(float(out[0]-d['x'][t]));iv=packet.get('intervals',np.full((1,2),np.nan))[0];ivs.append(iv)
        if name.startswith('Box'):
            miss=sum(not any(a<=d['x'][t]<=b for a,b in g) for g in model.geometry(y[0]));source_miss.append(miss)
            F=packet['components'][0];fullcover.append(any(a-1e-9<=d['x'][t]<=b+1e-9 for a,b in F));components.append(len(F));safecover.append(miss<=model.r)
        switch.append(bool(t==d['start'] or np.any(d['pattern'][t]!=d['pattern'][t-1])))
    e=np.array(errors);iv=np.array(ivs);valid=np.isfinite(iv).all(axis=1);cover=valid&(d['x'][d['start']:]>=iv[:,0])&(d['x'][d['start']:]<=iv[:,1]);post=np.zeros(len(e),bool)
    for t in np.flatnonzero(switch):post[t:min(len(e),t+3)]=True
    result=dict(case=case,seed=seed,method=name,params=params,mae=float(abs(e).mean()),rmse=float(np.sqrt(np.mean(e*e))),cum_abs=float(abs(e).sum()),first32=float(abs(e[:32]).mean()),worst32=float(np.convolve(abs(e),np.ones(32)/32,'valid').max()),switch_mae=float(abs(e[post]).mean()),valid_rate=float(valid.mean()),hull_coverage=float(cover.mean()) if name.startswith('Box') or name=='ModeSet' else None,interval_width=float(np.mean((iv[:,1]-iv[:,0])[valid])) if valid.any() else None,full_set_coverage=float(np.mean(fullcover)) if fullcover else None,assumption_holds_rate=float(np.mean(safecover)) if safecover else None,source_miss_mean=float(np.mean(source_miss)) if source_miss else None,disconnected_rate=float(np.mean(np.array(components)>1)) if components else None,warm_geometry=warmstats,meta=d['meta'],test_audits_returned=int(d['audit'][d['start']:len(d['x'])-c.delay].sum()),learning_audits_returned=int(d['audit'][:d['start']-c.delay+1].sum()),runtime=time.perf_counter()-startclock,N=N)
    if trace:return result,dict(error=e,intervals=iv,truth=d['x'][d['start']:],reports=d['y'][d['start']:],source_miss=np.array(source_miss),components=np.array(components))
    return result

def controls():
    return [('ModeSet',dict(threshold=4.,coverage=.875,width=2.)),('ModeMAP',dict(threshold=4.,cap=16.)),('Legacy:GainRepair',dict(rate=.2)),('Legacy:RLS',dict(forget=.9,rate=.1)),('WarmJoint',dict(forget=.97)),('ContrastKNN',dict(neighbors=4,memory=64)),('AuditTV',dict(window=32,lam=.5,max_iter=600)),('TimeKernel',dict(width=1.,tau=16.)),('LocalJoint',dict(width=3.,tau=32.))]

def cases(phase):
    base=[dict(ds='syn',scene=s,p=p) for s,p in [('seen',0.),('unseen',0.),('unseen',.25),('sync',.25)]]
    base += [dict(ds='syn',scene='unseen',p=.25,jitter=.1),dict(ds='syn',scene='unseen',p=.25,novel=2),dict(ds='syn',scene='unseen',p=.25,drift=.12),dict(ds='syn',scene='unseen',p=.25,hetero=0.)]
    if phase=='dev':return base
    base += [dict(ds='syn',scene='unseen',p=.25,jitter=.25),dict(ds='syn',scene='unseen',p=.25,novel=4),dict(ds='syn',scene='clean',p=.25),dict(ds='syn',scene='unseen',p=.1,delay=10)]
    base += [dict(ds=ds,scene=sc,p=p) for ds in ['air_hold1','air_hold2','air_hold3'] for sc,p in [('clean',.25),('unseen',0.),('unseen',.25)]]
    return base

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--phase',choices=['dev','confirm'],required=True);ap.add_argument('--workers',type=int,default=4);a=ap.parse_args();cfg=controls()
    if a.phase=='dev':
        cfg += [('BoxMode',dict(factor=f,fraction=r)) for f in [1.,1.4] for r in [0.,.125]]
        seeds=[61100,61101]
    else:
        best=json.loads((BASE/'selected.json').read_text())['BoxMode'];cfg += [(m,best) for m in ['BoxMode','BoxPoint','BoxVector','BoxSingle']]
        cfg += [('BoxMode_r0',{**best,'fraction':0.})] if best['fraction'] else [('BoxMode_r2',{**best,'fraction':.125})]
        seeds=list(range(62100,62106))
    cs=cases(a.phase);jobs=[(case,s,m,p) for case in cs for s in seeds for m,p in cfg];out=BASE/a.phase;out.mkdir(exist_ok=True);source=out/'source';source.mkdir(exist_ok=True)
    dep=list(BASE.glob('*.py'))+[BASE.parent/'v9'/f for f in ['candidates.py','temporal_baselines.py']]+[BASE.parent/'v10'/f for f in ['models.py','local_model.py']]
    hashes={str(p.relative_to(BASE.parent)):hashlib.sha256(p.read_bytes()).hexdigest() for p in dep}
    for p in BASE.glob('*.py'):shutil.copy2(p,source/p.name)
    (out/'frozen.json').write_text(json.dumps(dict(cases=cs,configs=cfg,seeds=seeds,jobs=len(jobs),hashes=hashes),indent=2));rows=[]
    with ProcessPoolExecutor(max_workers=a.workers) as pool:
        for f in as_completed([pool.submit(run,j) for j in jobs]):
            rows.append(f.result())
            if len(rows)%24==0:(out/'runs.json').write_text(json.dumps(rows,allow_nan=False));print(a.phase,len(rows),'/',len(jobs),flush=True)
    (out/'runs.json').write_text(json.dumps(rows,allow_nan=False))
    if a.phase=='dev':
        rank=[]
        for m,p in cfg:
            if m!='BoxMode':continue
            vals=[np.mean([r['mae'] for r in rows if r['case']==case and r['method']==m and r['params']==p]) for case in cs];rank.append(dict(params=p,mean_log_mae=float(np.mean(np.log(vals))),case_mae=vals))
        rank.sort(key=lambda x:x['mean_log_mae']);(BASE/'selected.json').write_text(json.dumps({'BoxMode':rank[0]['params']},indent=2));(out/'ranking.json').write_text(json.dumps(rank,indent=2))
    for f,h in hashes.items():assert hashlib.sha256((BASE.parent/f).read_bytes()).hexdigest()==h,f
    print('DONE',len(rows),flush=True)
if __name__=='__main__':main()
