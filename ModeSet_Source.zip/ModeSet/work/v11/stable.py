"""Numerically stable exponentially weighted ridge control; no covariance downdates."""
from pathlib import Path
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1');os.environ.setdefault('OMP_NUM_THREADS','1')
import importlib.util,json,hashlib,argparse
from concurrent.futures import ProcessPoolExecutor,as_completed
import numpy as np
BASE=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('v11_stable_protocol',BASE/'study.py');st=importlib.util.module_from_spec(sp);sp.loader.exec_module(st)
class StableJoint:
    def __init__(self,name,cal,c,p,seed=0,**params):
        self.base=None;self.N=c.N;self.J=c.J;self.forget=params.get('forget',.97);self.ridge=params.get('ridge',1.);self.prior=np.r_[np.ones(c.N)/c.N,-np.median(cal)];self.G=np.eye(c.N+1)*self.ridge;self.h=self.prior*self.ridge;self.theta=self.prior.copy()
    def initialize_history(self,y,audits,refs,warm,delay):
        for t in range(warm):
            if t+delay<=warm:
                for j in np.flatnonzero(audits[t]):self.update(y[t,j],refs[t,j])
    def update(self,y,v):
        X=np.r_[y,1.];self.G=self.forget*self.G+np.outer(X,X)+(1-self.forget)*self.ridge*np.eye(self.N+1);self.h=self.forget*self.h+X*v+(1-self.forget)*self.ridge*self.prior;self.theta=np.linalg.solve(self.G,self.h)
    def predict(self,y,commit=False,t=None):
        out=np.c_[y,np.ones(len(y))]@self.theta
        return out,dict(y=y.copy(),z=y.copy(),out=out.copy(),w=np.full_like(y,1/self.N),q=np.ones(self.N))
    def audit(self,t,packet,v,mask):
        for j in np.flatnonzero(mask):self.update(packet['y'][j],v[j])
old=st.construct
def factory(name,*a,**kw):return StableJoint(name,*a,**kw) if name=='StableJoint' else old(name,*a,**kw)
st.construct=factory
def worker(j):return st.run(j)
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--phase',choices=['stable_dev','stable_confirm'],required=True);a=ap.parse_args()
    if a.phase=='stable_dev':cfg=[('StableJoint',dict(forget=f,ridge=r)) for f in [.9,.97] for r in [.1,1.]];cs=st.cases('dev');seeds=[61100,61101]
    else:cfg=[('StableJoint',json.loads((BASE/'stable_selected.json').read_text()))];cs=st.cases('confirm');seeds=list(range(62100,62106))
    jobs=[(c,s,m,p) for c in cs for s in seeds for m,p in cfg];out=BASE/a.phase;out.mkdir(exist_ok=True);hashes={n:hashlib.sha256((BASE/n).read_bytes()).hexdigest() for n in ['core.py','data.py','study.py','stable.py']}
    (out/'frozen.json').write_text(json.dumps(dict(cases=cs,configs=cfg,seeds=seeds,jobs=len(jobs),hashes=hashes),indent=2));rows=[]
    with ProcessPoolExecutor(max_workers=3) as pool:
        for f in as_completed([pool.submit(worker,j) for j in jobs]):rows.append(f.result())
    (out/'runs.json').write_text(json.dumps(rows,allow_nan=False))
    if a.phase=='stable_dev':
        rank=[]
        for m,p in cfg:
            vals=[np.mean([r['mae'] for r in rows if (r['case'],r['method'],r['params'])==(c,m,p)]) for c in cs];rank.append(dict(params=p,mean_log_mae=float(np.mean(np.log(vals))),case_mae=vals))
        rank.sort(key=lambda x:x['mean_log_mae']);(BASE/'stable_selected.json').write_text(json.dumps(rank[0]['params'],indent=2));(out/'ranking.json').write_text(json.dumps(rank,indent=2))
    for n,h in hashes.items():assert hashlib.sha256((BASE/n).read_bytes()).hexdigest()==h
    print('DONE',a.phase,len(rows))
if __name__=='__main__':main()
