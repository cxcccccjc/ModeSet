"""Set-valued mode learning with explicit mismatch tolerance. Conditional, not a probabilistic certificate."""
import numpy as np

def merge(intervals):
    out=[]
    for a,b in sorted(intervals):
        if out and a<=out[-1][1]+1e-12:out[-1][1]=max(b,out[-1][1])
        else:out.append([float(a),float(b)])
    return out

def support_set(source_intervals,required):
    events={}
    for intervals in source_intervals:
        for a,b in merge(intervals):
            events.setdefault(a,[0,0])[0]+=1;events.setdefault(b,[0,0])[1]+=1
    pts=sorted(events);count=0;pieces=[]
    for h,x in enumerate(pts):
        count+=events[x][0]
        if count>=required:pieces.append((x,x))
        count-=events[x][1]
        if h+1<len(pts) and count>=required:pieces.append((x,pts[h+1]))
    return merge(pieces)

def confusion_radius(boxes,sigma,r):
    N=len(boxes)
    if N-2*r<=0:return None
    per=[]
    for i,states in enumerate(boxes):
        per.append([(a[0]-b[1]-2*sigma[i],a[1]-b[0]+2*sigma[i]) for a in states for b in states])
    F=support_set(per,N-2*r)
    return max(abs(F[0][0]),abs(F[-1][1])) if F else 0.

class BoxMode:
    def __init__(self,name,cal,c,p,seed=0,**params):
        self.name=name;self.base=None;self.c=c;self.N=c.N;self.J=c.J;self.params=params
        self.r=min((c.N-1)//2,int(np.floor(params.get('fraction',0.)*c.N)));self.K=1 if name=='BoxSingle' else 5
        med=np.median(cal,axis=0);self.sigma=np.maximum(.025,np.max(abs(cal-med),axis=0))*params.get('factor',1.2)
        self.ref_error=float(getattr(c,'reference_error',0.));self.E=self.sigma+self.ref_error
        self.boxes=[[[float(np.max(cal[:,i]-self.E[i])),float(np.min(cal[:,i]+self.E[i]))]] for i in range(self.N)]
        for i in range(self.N):
            if self.boxes[i][0][0]>self.boxes[i][0][1]:self.boxes[i]=[[float(med[i]-self.E[i]),float(med[i]+self.E[i])]]
        self.stamp=[[0] for _ in range(self.N)];self.generation=[[0] for _ in range(self.N)];self.serial=1;self.seq=0;self.patterns=[tuple((0,0) for _ in range(self.N))]
        self.multiple_matches=0;self.created=0
    def initialize_history(self,y,audits,refs,warm,delay):self.seq=warm
    def geometry(self,y):
        boxes=self.boxes
        if self.name=='BoxPoint':boxes=[[[.5*(a+b),.5*(a+b)] for a,b in states] for states in boxes]
        return [[(y[i]-b-self.sigma[i],y[i]-a+self.sigma[i]) for a,b in states] for i,states in enumerate(boxes)]
    def fallback(self,y):
        centers=[np.array([.5*(a+b) for a,b in bxs]) for bxs in self.boxes]
        grid=np.concatenate([y[i]-mu for i,mu in enumerate(centers)])
        residual=np.stack([np.min(abs(y[i]-grid[:,None]-mu[None,:]),axis=1)/self.sigma[i] for i,mu in enumerate(centers)],axis=1)
        score=np.minimum(residual**2,16.).sum(axis=1);x=float(grid[np.argmin(score)])
        for _ in range(2):
            z=np.array([y[i]-mu[np.argmin(abs(y[i]-x-mu))] for i,mu in enumerate(centers)]);x=float(np.median(z))
        return x,z
    def predict(self,y,commit=False,t=None):
        outs=[];intervals=[];zs=[];components=[]
        for yy in y:
            geometry=self.geometry(yy)
            if self.name=='BoxVector':
                pieces=[]
                for pat in self.patterns:
                    if all(k<len(self.boxes[i]) and self.generation[i][k]==g for i,(k,g) in enumerate(pat)):
                        pieces.extend(support_set([[geometry[i][k]] for i,(k,g) in enumerate(pat)],self.N-self.r))
                F=merge(pieces)
            else:F=support_set(geometry,self.N-self.r)
            fallback,z=self.fallback(yy)
            outs.append(.5*(F[0][0]+F[-1][1]) if F else fallback);intervals.append((F[0][0],F[-1][1]) if F else (np.nan,np.nan));zs.append(z);components.append(F)
        if commit:self.seq=t+1 if t is not None else self.seq+1
        out=np.array(outs)
        return out,dict(y=y.copy(),z=np.array(zs),out=out.copy(),w=np.full_like(y,1/self.N),q=self.sigma**2,intervals=np.array(intervals),components=components)
    def audit(self,t,packet,v,mask):
        for j in np.flatnonzero(mask):
            residual=packet['y'][j]-v[j];pattern=[]
            for i,a in enumerate(residual):
                lo=float(a-self.E[i]);hi=float(a+self.E[i]);hits=[k for k,(u,w) in enumerate(self.boxes[i]) if max(lo,u)<=min(hi,w)+1e-12]
                if len(hits)==1:
                    k=hits[0];b=self.boxes[i][k];b[0]=max(b[0],lo);b[1]=min(b[1],hi)
                elif not hits:
                    if len(self.boxes[i])<self.K:
                        k=len(self.boxes[i]);self.boxes[i].append([lo,hi]);self.stamp[i].append(self.seq);self.generation[i].append(self.serial)
                    else:
                        k=0 if self.K==1 else 1+int(np.argmin(self.stamp[i][1:]));self.boxes[i][k]=[lo,hi];self.generation[i][k]=self.serial
                    self.serial+=1;self.created+=1
                else:
                    # Ambiguous observations must not shrink every candidate state.
                    self.multiple_matches+=1;pattern.append(None);continue
                self.stamp[i][k]=self.seq;pattern.append((k,self.generation[i][k]))
            if all(x is not None for x in pattern):
                pattern=tuple(pattern)
                if pattern not in self.patterns:self.patterns.append(pattern)
                self.patterns=self.patterns[-256:]

