from pathlib import Path
import csv,itertools,hashlib,json
import numpy as np
BASE=Path(__file__).resolve().parent
REAL=None
def real_streams():
    global REAL
    if REAL is not None:return REAL
    file=BASE.parent/'data/uci_air_quality/AirQualityUCI.csv';cols=['CO(GT)','PT08.S1(CO)','PT08.S2(NMHC)','PT08.S3(NOx)','PT08.S4(NO2)','PT08.S5(O3)'];a=[];dates=[]
    with file.open(encoding='utf8') as f:
        for row in csv.DictReader(f,delimiter=';'):
            if not row.get('Date'):continue
            v=[float(row[k].replace(',','.')) for k in cols]
            if -200 not in v:a.append(v);dates.append(row['Date']+' '+row['Time'])
    a=np.array(a);target=a[:,0];sd=target[:1000].std();truth=(target-target[:1000].mean())/sd;reports=[]
    for i in range(1,6):
        z=(a[:,i]-a[:1000,i].mean())/a[:1000,i].std();A=np.c_[np.ones(len(z)),z,z*z];coef=np.linalg.solve(A[:1000].T@A[:1000]+np.diag([0.,1.,1.]),A[:1000].T@truth[:1000]);reports.append(A@coef)
    pred=np.array(reports).T;REAL={}
    for name,start in [('air_hold1',1700),('air_hold2',3000),('air_hold3',6000)]:
        REAL[name]=(np.r_[pred[1000:1300],pred[start:start+480]],np.r_[truth[1000:1300],truth[start:start+480]],300,dict(raw_range=[start,start+480],first=dates[start],last=dates[start+479],scale=float(sd),csv_sha256=hashlib.sha256(file.read_bytes()).hexdigest()))
    return REAL

def make(seed,ds='syn',scene='unseen',p=.0,delay=2,jitter=0.,novel=0,drift=0.,hetero=1.,common=False):
    rng=np.random.default_rng(seed);fit=160;calpart=80;T=240
    if ds=='syn':
        N=16;warm=96;n=warm+fit+calpart+T;tt=np.arange(n);truth=.6*np.sin(tt/18)+np.cumsum(rng.normal(0,.018,n));truth[warm+fit+calpart+60:]+=1.6;truth[warm+fit+calpart+150:]-=2.3
        base=rng.uniform(-.08,.08,N);sigma=np.r_[np.full(12,.035),np.full(4,.14)];noise=rng.uniform(-1,1,(n,N))*sigma+rng.uniform(-.018,.018,(n,4)).repeat(4,axis=1)
        reports=truth[:,None]+base+noise;ref=truth+rng.uniform(-.015,.015,n);meta=dict(source_noise_bound=(sigma+.018).tolist(),bias=base.tolist());referror=.015
    else:
        reports,truth,warm,meta=real_streams()[ds];reports=reports.copy();truth=truth.copy();N=reports.shape[1];ref=truth.copy();referror=0.;n=len(truth)
    audit=np.zeros(n,bool);audit[:warm]=True;audit[warm:warm+fit+calpart]=rng.random(fit+calpart)<.25;audit[warm+fit+calpart:]=rng.random(T)<p
    visible=np.arange(warm-delay+1);q=np.mean((reports[visible]-ref[visible,None])**2,axis=0);C=N if common else int(np.ceil(.75*N));bad=np.argsort(q)[:C];active=C if common else int(np.ceil(.75*C))
    combos=list(itertools.combinations(range(C),active)) if not common else [tuple(range(C))]
    if common:combos=[tuple([k]) for k in range(C)]
    rng.shuffle(combos);cut=min(24,len(combos)//2);train=combos[:cut];test=combos[cut:cut+max(1,cut)]
    if scene=='seen':test=train
    if scene=='sync' or common:test=[tuple(range(C))]
    if not test:test=train
    amp=np.full(C,1.5)+hetero*np.linspace(-.55,.55,C);pattern=np.zeros((n,N),int);split=warm+fit+calpart
    for a,b,pool in [(warm,split,train),(split,n,test)]:
        t=a
        while t<b:
            ids=pool[int(rng.integers(len(pool)))];length=int(rng.integers(1,9));pattern[t:min(b,t+length),bad[list(ids)]]=1;t+=length
    attacked=reports.copy();payload=pattern[:,bad]*amp
    payload[split:]*=1+rng.uniform(-jitter,jitter,(T,C))
    if novel:payload[split:,:min(novel,C)]+=pattern[split:,bad[:min(novel,C)]]*.8
    if scene=='clean':pattern[:]=0;payload[:]=0
    attacked[:,bad]+=payload
    if drift:attacked[split:]+=drift*np.sin(np.arange(T)[:,None]/45+np.arange(N)[None,:]/3)
    train_vectors={tuple(s) for s in pattern[warm:split]};test_vectors={tuple(s) for s in pattern[split:]}
    observed=np.flatnonzero(audit[:split]&(np.arange(split)+delay<=split));covered=all(any(pattern[t,i]==1 for t in observed) for i in bad) if scene!='clean' else True
    trainset={tuple(bad[list(s)]) for s in train};testset={tuple(bad[list(s)]) for s in test}
    meta.update(train_pattern_count=len(train_vectors),test_pattern_count=len(test_vectors),joint_overlap=len(train_vectors&test_vectors),each_active_source_audited=bool(covered),train_patterns=[list(s) for s in train],heldout_patterns=[list(s) for s in test],controlled=bad.tolist(),amplitudes=amp.tolist(),current_active_count=active,physical_data='synthetic' if ds=='syn' else 'real_reports_with_injected_attacks',test_reference_probability=p)
    return dict(y=attacked,clean=reports,x=truth,ref=ref,audit=audit,warm=warm,fit=fit,calpart=calpart,start=split,T=T,N=N,bad=bad,pattern=pattern,meta=meta,reference_error=referror,p=p,delay=delay,case=dict(ds=ds,scene=scene,p=p,delay=delay,jitter=jitter,novel=novel,drift=drift,hetero=hetero,common=common))
