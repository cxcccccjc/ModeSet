"""Source-bounded *numerical cores*, NOT full PRTD or VRPMTD reproductions.

PRTD: PDF pp.6-9, Eqs.(7),(15),(16),(20),(22),(23), Algorithms 2-4.
VRPMTD: PDF pp.8-10, Eqs.(5)-(7),(11),(12), Algorithm 2 and V-D Step 5.
No cryptography, quantization, network dropout, malicious packet verification,
or paper datasets are reproduced. Scalar instantiation is deliberate.
See ../prtd_vrpmtd_reading.md for every ambiguity/adaptation.
"""
from dataclasses import dataclass
from collections import deque
import numpy as np


def _vector(x):
    x = np.asarray(x, dtype=float)
    if x.ndim != 1 or not len(x) or not np.all(np.isfinite(x)):
        raise ValueError('Expected a complete finite scalar-report vector; no missing-data adaptation.')
    return x


def prtd_levels(reputations, t0=.2, tau=.1):
    """Eq.(7); >0 requires reputation >= t0+tau, not merely >=t0."""
    r = _vector(reputations)
    if tau <= 0: raise ValueError('tau must be positive')
    # Tiny rounding tolerance only avoids floor(0.3-0.2)/0.1 becoming zero.
    return np.where(r >= t0, np.maximum(0, np.floor((r-t0)/tau+1e-12)), 0.)


def _distance(y, truth, distance):
    if distance == 'squared': return (y-truth)**2
    if distance == 'absolute': return np.abs(y-truth)
    raise ValueError('The paper leaves d generic; choose squared or absolute explicitly.')


def prtd_quality(y, reference, xi, distance='squared'):
    """Eq.(22). xi is REQUIRED: its numeric value was not located in the PDF."""
    if xi <= 0: raise ValueError('xi must be positive')
    inv = 1. / (_distance(_vector(y), float(reference), distance)+xi)
    return inv/inv.sum()


def prtd_reputation_update(levels, quality):
    """Eq.(23)/Algorithm 4, scalar M=1, literal replacement (not an EWMA)."""
    a = np.asarray(levels)*np.asarray(quality)-1.
    return 1./(1.+np.exp(-np.clip(a, -700, 700)))


def prtd_scalar_core(y, reputations, *, xi, t0=.2, tau=.1,
                     distance='squared', initial_truth=None, rng=None,
                     tol=.05, max_iter=200, numerical_floor=1e-12):
    """PRTD scalar plaintext Eq.(16),(20) fixed-point iteration.

    Random initialization is in Alg.2, but its distribution is not specified.
    Without initial_truth we use uniform[min(y),max(y)] with provided rng.
    numerical_floor is a disclosed implementation guard for log(0).
    All-zero levels return NaN/status, NOT a secretly substituted median.
    """
    y = _vector(y); r = _vector(reputations)
    if len(y) != len(r): raise ValueError('y/reputation lengths differ')
    levels = prtd_levels(r,t0,tau); use = levels>0
    if use.sum()<2:
        return dict(truth=float('nan'),weights=np.zeros_like(y),levels=levels,
                    quality=None,next_reputation=r.copy(),iterations=0,
                    status='undefined_fewer_than_two_positive_levels')
    if initial_truth is None:
        rng = np.random.default_rng(0) if rng is None else rng
        truth = float(rng.uniform(y[use].min(),y[use].max()))
    else: truth=float(initial_truth)
    status='max_iter'; weights=np.zeros_like(y)
    for iteration in range(1,max_iter+1):
        d=np.maximum(_distance(y,truth,distance),numerical_floor)
        term=levels[use]*d[use]
        omega=np.log(term.sum())-np.log(term)
        eff=levels[use]*omega
        if eff.sum()<=0 or not np.all(np.isfinite(eff)):
            return dict(truth=float('nan'),weights=weights,levels=levels,quality=None,
                        next_reputation=r.copy(),iterations=iteration,status='undefined_zero_weight_sum')
        weights[:]=0.; weights[use]=eff/eff.sum()
        updated=float(weights@y)
        if abs(updated-truth)<tol:
            truth=updated;status='converged';break
        truth=updated
    # The equation prints normalization over all K workers, not just admitted workers.
    quality=prtd_quality(y,truth,xi,distance)
    return dict(truth=truth,weights=weights,levels=levels,quality=quality,
                next_reputation=prtd_reputation_update(levels,quality),
                iterations=iteration,status=status)


class PRTDScalarState:
    """Repeated-task scalar ADAPTATION; retain/report zero-admission failures.

    update_mode='self' follows Eq.(22)-(23) using the inferred current truth.
    update_mode='fixed' holds externally supplied reputations fixed (control).
    update_mode='audit' is an EXPLICIT benchmark adapter: only a supplied
    independent audit updates reputations, replacing the Eq.(22) reference.
    None of these modes implements PRTD cryptography or unknown scalar choices.
    """
    def __init__(self,reputations,*,xi,update_mode='self',seed=0,**kwargs):
        if update_mode not in ('self','fixed','audit'): raise ValueError(update_mode)
        self.reputations=_vector(reputations).copy();self.xi=xi
        self.update_mode=update_mode;self.rng=np.random.default_rng(seed);self.kwargs=kwargs
    def step(self,y,audit_reference=None):
        out=prtd_scalar_core(y,self.reputations,xi=self.xi,rng=self.rng,**self.kwargs)
        if out['quality'] is not None:
            if self.update_mode=='self':self.reputations=out['next_reputation'].copy()
            elif self.update_mode=='audit' and audit_reference is not None:
                q=prtd_quality(y,audit_reference,self.xi,self.kwargs.get('distance','squared'))
                self.reputations=prtd_reputation_update(out['levels'],q)
        out['stored_reputation']=self.reputations.copy()
        return out


def vrpmtd_incremental_step(previous_truth,current_reports,previous_reports,weights,
                           active=None):
    """Printed V-D Step5, PDF p.10, with all responsive sources in denominator."""
    y=_vector(current_reports);old=_vector(previous_reports);w=_vector(weights)
    if y.shape!=old.shape or y.shape!=w.shape:raise ValueError('shape mismatch')
    if np.any(w<0) or w.sum()<=0:raise ValueError('nonnegative positive-sum weights required')
    active=np.ones(len(y),bool) if active is None else np.asarray(active,bool)
    return float(previous_truth+np.dot(w[active],(y-old)[active])/w.sum())


class VRPMTDScalarState:
    """Noiseless scalar RBF+sliding-window numerical core.

    Required xi and scale: neither the floor xi nor scale estimator is fully
    numerically specified in the PDF. TableII supplies window=10,decay=.8,
    sigma_rbf=.2,upload_threshold=.03.

    update_mode='absolute': same published weights, full current reaggregation;
      explicitly an adapted weighting baseline, NOT printed delta protocol.
    update_mode='differential': printed incremental formula after a one-shot
      mean bootstrap; bootstrap is disclosed because printed first-round full
      uploads plus nonzero initial mean otherwise double-count initialization.
    update_mode='literal_initialization': intentionally demonstrates the printed
      full-upload/nonzero-initial-mean ambiguity; not recommended for headline.

    report_memory='last_reported' interprets Algorithm2's prior reported vector
      literally; 'previous_observed' is a sensitivity alternative.
    No audit inputs; these weights are computed from prior inferred truth.
    """
    def __init__(self,n_sources,*,xi,scale,window=10,decay=.8,sigma_rbf=.2,
                 upload_threshold=.03,update_mode='absolute',report_memory='last_reported'):
        if n_sources<2 or xi<=0 or scale<=0 or window<1 or not 0<decay<=1 or sigma_rbf<=0:
            raise ValueError('invalid scalar-core parameters')
        if update_mode not in ('absolute','differential','literal_initialization'):raise ValueError(update_mode)
        if report_memory not in ('last_reported','previous_observed'):raise ValueError(report_memory)
        self.n=n_sources;self.xi=xi;self.scale=scale;self.L=window;self.gamma=decay
        self.sigma=sigma_rbf*scale;self.threshold=upload_threshold;self.mode=update_mode
        self.memory=report_memory;self.losses=deque();self.acc=np.zeros(n_sources)
        self.truth=None;self.previous=None;self.round=0
    def step(self,y):
        y=_vector(y)
        if len(y)!=self.n:raise ValueError('fixed participation core only')
        first=self.truth is None
        previous_truth=float(y.mean()) if first else self.truth
        loss=self.xi+1.-np.exp(-.5*((y-previous_truth)/self.sigma)**2)
        self.acc=self.gamma*self.acc+loss
        if len(self.losses)==self.L:self.acc-=self.gamma**self.L*self.losses.popleft()
        self.losses.append(loss.copy())
        # Fixed participation + no masking noise => global accumulator equals local sum.
        global_acc=float(self.acc.sum())
        w=np.log(global_acc)-np.log(np.maximum(self.acc,np.finfo(float).tiny))
        if first:
            out=previous_truth
            if self.mode=='literal_initialization':out=previous_truth+float(y.mean())
            normalized=np.ones(self.n)/self.n;active=np.ones(self.n,bool)
            self.previous=y.copy()
        else:
            normalized=w/w.sum()
            change=y-self.previous
            active=np.abs(change)/self.scale>self.threshold
            if self.mode=='absolute':out=float(normalized@y)
            else:out=vrpmtd_incremental_step(previous_truth,y,self.previous,w,active)
            if self.memory=='previous_observed' or self.mode=='absolute':self.previous=y.copy()
            else:self.previous[active]=y[active]
        self.truth=out;self.round+=1
        return dict(truth=out,weights=normalized,loss=loss,accumulator=self.acc.copy(),
                    active=active,round=self.round,mode=self.mode,
                    reproduction_scope='scalar_noiseless_weight_core_and_explicit_update_variant')


def self_check():
    """Meaningful formula checks plus scoped counterexamples, not paper benchmarks."""
    # Equal reports are numerically handled, while repeated literal reputation loses admission.
    st=PRTDScalarState(np.full(24,.75),xi=.001,tol=.05)
    collapse=[]
    for _ in range(3):
        r=st.step(np.ones(24));collapse.append(dict(truth=r['truth'],level=float(r['levels'][0]),
            rep=float(r['stored_reputation'][0]),status=r['status']))
    assert collapse[0]['level']==5 and collapse[1]['level']==1 and collapse[2]['level']==0
    assert np.isnan(collapse[2]['truth'])
    # Exact finite-window accumulator against direct summation.
    vr=VRPMTDScalarState(3,xi=.001,scale=1,window=3,decay=.8)
    seen=[]
    for i in range(9):
        r=vr.step(np.array([0.,.1,.2])+i*.03);seen.append(r['loss'])
        direct=sum(.8**k*seen[-1-k] for k in range(min(3,len(seen))))
        assert np.allclose(r['accumulator'],direct)
    # Printed incremental formula is path-dependent under changing weights.
    y0=np.zeros(3);y1=np.array([0.,0.,1.]);y2=np.zeros(3)
    x1=vrpmtd_incremental_step(0,y1,y0,np.array([1.,1.,8.]))
    x2=vrpmtd_incremental_step(x1,y2,y1,np.array([1.,1.,.1]))
    assert x1==.8 and x2>.75 and y2.mean()==0
    return dict(prtd_equal_honest_repeated_scalar=collapse,
                incremental_formula_ratchet=dict(attack_phase_estimate=x1,
                  returned_all_zero_reports_estimate=x2,absolute_reaggregation=0.),
                caveat='Counterexample weights are prescribed, not claimed as a trained full-paper attack.')


if __name__=='__main__':
    import json
    print(json.dumps(self_check(),indent=2))
