"""Auditable numerical kernels, NOT complete reproductions of MDM 2022 or CPDZ.

See ../mdm_cpdz_reading.md for formula mappings and unresolved source ambiguities.
Arrays use (worker, task/attribute); only finite, complete matrices are supported.
CPDZ's recruitment, cryptographic protocol and ambiguous printed TAST are omitted.
"""

from __future__ import annotations

from dataclasses import dataclass
from math import comb, isfinite
from typing import Literal

import numpy as np


def _matrix(y):
    y = np.asarray(y, dtype=float)
    if y.ndim != 2 or min(y.shape) == 0 or not np.all(np.isfinite(y)):
        raise ValueError("Y must be a nonempty finite worker-by-task matrix")
    return y


def _normalize(w):
    w = np.asarray(w, dtype=float)
    if np.any(w < 0) or not np.all(np.isfinite(w)):
        raise ValueError("weights must be finite and nonnegative")
    if np.sum(w) <= 0:
        return np.ones_like(w) / w.size
    return w / np.sum(w)


class MDMOptimizedTruthFinder:
    """MDM 2022 Algorithm 1: signed Eq.3 and mean-of-ratios reading of Eq.5.

    The paper leaves d() unspecified and Eq.5's denominator index scope unclear.
    `distance` therefore records an assumption, not a recovered paper setting.
    The paper uses epsilon=6, max_iter=20, and resets every 24 rounds.
    round_index is zero-based; reset applies at rounds 0,24,48,... .
    """

    def __init__(self, n_workers=None, *, epsilon=6.0, max_iter=20,
                 reset_interval=24, distance: Literal["squared", "absolute"]="squared",
                 tol=1e-8, numeric_floor=1e-12):
        if epsilon <= 2 or max_iter < 1 or numeric_floor <= 0:
            raise ValueError("epsilon > 2, max_iter >= 1 and a positive floor required")
        if distance not in ("squared", "absolute"):
            raise ValueError("unknown distance assumption")
        if reset_interval is not None and reset_interval < 1:
            raise ValueError("reset interval must be positive or None")
        self.epsilon, self.max_iter = float(epsilon), int(max_iter)
        self.reset_interval, self.distance = reset_interval, distance
        self.tol, self.numeric_floor = float(tol), float(numeric_floor)
        self.weights = None if n_workers is None else np.ones(n_workers)/n_workers
        self.last_inner_truth = None
        self.last_truth = None

    def predict(self, Y, round_index):
        y = _matrix(Y)
        n = y.shape[0]
        if self.weights is not None and len(self.weights) != n:
            raise ValueError("worker identities/count must remain fixed")
        if (self.weights is None or
                (self.reset_interval is not None and round_index % self.reset_interval == 0)):
            self.weights = np.ones(n)/n
        initial = self.weights.copy()  # Eq.5 uses INITIAL weight of this round.
        w = initial.copy()
        previous = None
        for _ in range(self.max_iter):
            x = w @ y  # Eq.1; all stored weights are normalized.
            residual = np.abs(y - x)
            dist = residual**2 if self.distance == "squared" else residual
            di = np.sum(dist, axis=1)
            total = np.sum(di)
            if total <= self.numeric_floor:
                break  # Numerical convention for otherwise undefined 0/0.
            w = _normalize(np.sqrt(total / np.maximum(di, self.numeric_floor)))
            if previous is not None and np.max(np.abs(x-previous)) <= self.tol:
                break
            previous = x.copy()
        # Algorithm 1 returns the last Eq.1 truth before the Eq.5 adjustment.
        self.last_inner_truth = x.copy()
        d = y - x  # SIGNED in the printed Eq.3. Do not silently take abs here.
        mean_d = np.mean(d, axis=0)
        denominator = np.abs(d) + np.abs(mean_d)
        ratio = np.divide(2*(d-mean_d), denominator,
                          out=np.zeros_like(d), where=denominator > self.numeric_floor)
        # Explicit dimensionally consistent reading of Eq.5's ambiguous m scope.
        self.weights = _normalize(initial * (1-np.mean(ratio, axis=1)/self.epsilon))
        self.last_truth = self.weights @ y
        return self.last_truth.copy()

    def update_audit(self, Y, v, audited_mask):
        """No-op: the paper's defense has no audit/reference input."""
        return None


@dataclass(frozen=True)
class TASTDiagnostic:
    valid: bool
    probability: float | None
    reason: str


def cpdz_printed_tast(alpha, beta, short_alpha, short_beta):
    """Evaluate printed CPDZ Eq.28 only in its ordinary-binomial domain.

    Eq.27 defines alpha=successes, beta=failures (possibly noninteger), whereas
    Eq.28 behaves like a formula using beta=total observations. No silent repair.
    A valid result here also does NOT validate the formula's statistical meaning.
    """
    vals = [alpha, beta, short_alpha, short_beta]
    if not all(isfinite(float(x)) and x >= 0 and float(x).is_integer() for x in vals):
        return TASTDiagnostic(False, None, "ordinary binomial coefficients require nonnegative integer parameters")
    a, b, sa, sb = map(int, vals)
    terms = [(a, a-sa), (b-a, b-a-sb+sa), (b, b-sb)]
    if any(nn < 0 or kk < 0 or kk > nn for nn, kk in terms):
        return TASTDiagnostic(False, None, "printed Eq.28 has a binomial term outside 0 <= k <= n")
    p = comb(*terms[0])*comb(*terms[1])/comb(*terms[2])
    return TASTDiagnostic(True, float(p), "literal value only; Eq.27/Eq.28 parameter semantics remain unresolved")


class _CPDZCore:
    """Eq.15/25/27 with full participation and no TAST.

    delta is REQUIRED and is a SQUARED-error threshold (Eq.1/5).
    phi, gamma, max_iter, tol and initialization choices must be reported.
    Defaults apart from alpha=beta=1 are numerical choices, not paper defaults.
    """

    def __init__(self, n_workers=None, *, delta, phi=1.0, gamma=1.0,
                 max_iter=50, tol=1e-8, numeric_floor=1e-12,
                 initialization: Literal["observed_range_uniform", "mean"]="observed_range_uniform",
                 seed=0):
        if delta < 0 or not 0 < phi <= 1 or gamma <= 0 or max_iter < 1 or numeric_floor <= 0:
            raise ValueError("invalid CPDZ numerical parameters")
        if initialization not in ("observed_range_uniform", "mean"):
            raise ValueError("unknown initialization")
        self.delta, self.phi, self.gamma = float(delta), float(phi), float(gamma)
        self.max_iter, self.tol, self.numeric_floor = int(max_iter), float(tol), float(numeric_floor)
        self.initialization = initialization
        self.rng = np.random.default_rng(seed)
        self.alpha = None if n_workers is None else np.ones(n_workers)
        self.beta = None if n_workers is None else np.ones(n_workers)
        self.last_truth = None
        self.last_weights = None

    def _ensure(self, n):
        if self.alpha is None:
            self.alpha = np.ones(n)
            self.beta = np.ones(n)
        elif len(self.alpha) != n:
            raise ValueError("worker identities/count must remain fixed")

    @property
    def credibility(self):
        return None if self.alpha is None else self.alpha / (self.alpha+self.beta)

    def _truth(self, y):
        self._ensure(y.shape[0])
        q = self.credibility  # Eq.23 without a UAV: LoC_i = DoC_i.
        if self.initialization == "mean":
            x = np.mean(y, axis=0)
        else:
            # Paper says random initialization; it does not specify a distribution.
            x = self.rng.uniform(np.min(y, axis=0), np.max(y, axis=0))
        for _ in range(self.max_iter):
            dist = (y-x)**2  # Eq.1.
            # Positive floor makes both perfect agreement and zero residual finite.
            dist = np.maximum(dist, self.numeric_floor)
            ratio = dist / np.sum(dist, axis=0, keepdims=True)
            w = -q[:, None] * np.log(ratio)  # Eq.25.
            denom = np.sum(w, axis=0)
            # One-worker case gives log(1)=0; return that worker's observation.
            zero = denom <= self.numeric_floor
            w[:, zero] = q[:, None]
            w = w / np.sum(w, axis=0, keepdims=True)
            new_x = np.sum(w*y, axis=0)  # Eq.4.
            if np.max(np.abs(new_x-x)) <= self.tol:
                x = new_x
                break
            x = new_x
        self.last_weights = w.copy()
        self.last_truth = x.copy()
        return x

    def _update(self, y, reference, mask):
        ref = np.asarray(reference, dtype=float)
        mask = np.asarray(mask, dtype=bool)
        if ref.shape != (y.shape[1],) or mask.shape != ref.shape:
            raise ValueError("reference and mask must have shape (tasks,)")
        if not np.all(np.isfinite(ref[mask])):
            raise ValueError("selected reference values must be finite")
        good = (y[:, mask]-ref[mask])**2 <= self.delta  # Eq.5; squared units.
        self.alpha = np.maximum(self.phi*self.alpha+self.gamma*np.sum(good, axis=1), self.numeric_floor)
        self.beta = np.maximum(self.phi*self.beta+self.gamma*np.sum(~good, axis=1), self.numeric_floor)


class CPDZNativeNumericalCore(_CPDZCore):
    """Current UAV truth replacement + all-task label updates; no TAST/recruitment.

    Call predict(..., reference=..., supervised_mask=...) when current-round UAV
    observations are available before publication. Unsupervised tasks update from
    the model's estimated truth, exactly the information policy of Eq.27/Alg.2.
    """

    def predict(self, Y, round_index, *, reference=None, supervised_mask=None):
        y = _matrix(Y)
        out = self._truth(y)
        mask = np.zeros(y.shape[1], dtype=bool) if supervised_mask is None else np.asarray(supervised_mask, dtype=bool)
        if mask.shape != (y.shape[1],):
            raise ValueError("supervised_mask must have shape (tasks,)")
        if np.any(mask):
            v = np.asarray(reference, dtype=float)
            if v.shape != mask.shape or not np.all(np.isfinite(v[mask])):
                raise ValueError("finite current reference required on supervised tasks")
            # Eq.23: worker LoC=0 and UAV LoC=1 -> exact current UAV output.
            out[mask] = v[mask]
            self.last_weights[:, mask] = 0.0  # UAV carries the entire omitted mass.
        self.last_truth = out.copy()
        self._update(y, out, np.ones(y.shape[1], dtype=bool))
        return out.copy()

    def update_audit(self, Y, v, audited_mask):
        if np.any(audited_mask):
            raise ValueError("native CPDZ consumes current references in predict; use CPDZSharedAuditAdaptation for post-output audits")


class CPDZSharedAuditAdaptation(_CPDZCore):
    """Explicit adaptation: no current truth replacement; audit-only Eq.27 labels.

    Invoke update_audit once per round, even when its mask is empty, to apply phi
    once. Audits may refer to older Y; their labels enter the state when returned.
    Unsupervised pseudo-labels from original CPDZ are intentionally excluded.
    This class is NOT the original CPDZ protocol or its TAST ablation as published.
    """

    def predict(self, Y, round_index):
        return self._truth(_matrix(Y)).copy()

    def update_audit(self, Y, v, audited_mask):
        y = _matrix(Y)
        self._ensure(y.shape[0])
        self._update(y, v, audited_mask)


def self_check():
    """Equation-derived cases, degeneracies, timing and known ambiguity checks."""
    constant = np.full((4, 3), 7.0)
    mdm = MDMOptimizedTruthFinder()
    assert np.allclose(mdm.predict(constant, 0), 7)
    assert np.allclose(mdm.weights, .25)
    # One inner iteration: Eq.1 -> 1; signed offsets [-1,+1]; Eq.5 -> [2/3,1/3].
    a = MDMOptimizedTruthFinder(max_iter=1)
    assert np.allclose(a.predict([[0.0], [2.0]], 0), [2/3])
    assert np.allclose(a.weights, [2/3, 1/3])
    b = MDMOptimizedTruthFinder(max_iter=1)
    assert np.allclose(b.predict([[0.0], [-2.0]], 0), [-4/3])
    # Reflection asymmetry is in the printed signed rule, not silently repaired.
    assert not np.allclose(a.last_truth, -b.last_truth)
    a.predict([[0.0], [2.0]], 24)
    assert np.allclose(a.weights, [2/3, 1/3])
    native = CPDZNativeNumericalCore(delta=1.0, initialization="mean")
    assert np.allclose(native.predict(constant, 0), 7)
    assert np.allclose(native.alpha, 4) and np.allclose(native.beta, 1)
    native = CPDZNativeNumericalCore(delta=1.0, initialization="mean")
    assert np.allclose(native.predict([[10.0], [20.0]], 0,
                       reference=[50.0], supervised_mask=[True]), 50)
    assert np.allclose(native.alpha, 1) and np.allclose(native.beta, 2)
    shared = CPDZSharedAuditAdaptation(delta=.25, phi=.9, gamma=2, initialization="mean")
    y = np.array([[1., 9.], [2., 9.]])
    out = shared.predict(y, 0).copy()
    shared.update_audit(y, [1.5, np.nan], [True, False])
    assert np.allclose(shared.alpha, 2.9) and np.allclose(shared.beta, .9)
    assert np.allclose(shared.last_truth, out)  # Audit cannot revise published output.
    shared.update_audit(y, [np.nan, np.nan], [False, False])
    assert np.allclose(shared.alpha, 2.61) and np.allclose(shared.beta, .81)
    assert cpdz_printed_tast(2, 5, 1, 2).valid
    assert np.isclose(cpdz_printed_tast(2, 5, 1, 2).probability, .6)
    assert not cpdz_printed_tast(9, 2, 3, 1).valid
    assert not cpdz_printed_tast(2.5, 5, 1, 2).valid
    for cls in (CPDZNativeNumericalCore, CPDZSharedAuditAdaptation):
        m = cls(delta=1)
        assert np.allclose(m.predict([[3., 5.]], 0), [3, 5])
    return {"status": "passed", "claims": "numerical checks only, not full paper reproduction"}


if __name__ == "__main__":
    print(self_check())
