"""Scalar numerical instantiation of Yan et al., IoTJ 2022 (not full reproduction).

PDF pp.6-9: g(w)=-log(w), continuous distance=abs(y-truth)/std(y),
truth update solves a weighted absolute loss; weight update solves simplex
cross-entropy; reputation is inverse normalized loss contribution with decay.
See ../longterm_reading.md for zero-distance and solver ambiguities.
No external audits, no malicious-identity labels, no cryptographic protocol.
"""
import numpy as np


def weighted_median(y,coefficients):
    """Exact minimizer of sum c_i|y_i-x|; midpoint for a nonunique interval."""
    y=np.asarray(y,float);c=np.asarray(coefficients,float)
    if np.any(c<0) or c.sum()<=0:raise ValueError('positive-sum coefficients required')
    order=np.argsort(y,kind='stable');yy=y[order];cc=c[order];s=np.cumsum(cc)
    half=.5*s[-1];i=int(np.searchsorted(s,half,side='left'))
    if i+1<len(y) and abs(s[i]-half)<=1e-12*max(1.,s[-1]):
        return float((yy[i]+yy[i+1])/2.)
    return float(yy[i])


class LongTermScalarState:
    """Continuous scalar/full-participation core of Algorithm1.

    Defaults decay=.99 and relative_tol=.001 are in PDF p.9.
    reward_total=1 is an innocuous normalization (common award R cancels).
    Floors and max_iter are implementation choices, NOT paper defaults.
    All source ages are equal; accumulated and per-age-average reputation have
    identical normalized initial weights under this fixed-participation scope.
    g(w), not w, is the coefficient in the truth objective.
    """
    def __init__(self,n_sources,*,decay=.99,relative_tol=.001,max_iter=200,
                 distance_floor=1e-12,loss_share_floor=1e-12,scale_floor=1e-12,
                 reward_total=1.,initial_reputation=None):
        if n_sources<2 or not 0<decay<=1:raise ValueError('invalid source count/decay')
        if min(distance_floor,loss_share_floor,scale_floor)<=0:raise ValueError('floors must be positive')
        self.n=n_sources;self.decay=decay;self.tol=relative_tol;self.max_iter=max_iter
        self.dfloor=distance_floor;self.lfloor=loss_share_floor;self.sfloor=scale_floor
        self.reward_total=reward_total;self.round=0
        self.reputation=np.zeros(n_sources) if initial_reputation is None else np.asarray(initial_reputation,float).copy()
        if self.reputation.shape!=(n_sources,) or np.any(self.reputation<0):raise ValueError('invalid reputation')
    def step(self,reports):
        y=np.asarray(reports,float)
        if y.shape!=(self.n,) or not np.isfinite(y).all():raise ValueError('complete scalar reports required')
        old_rep=self.reputation.copy()
        w=np.ones(self.n)/self.n if old_rep.sum()==0 else old_rep/old_rep.sum()
        # Strict positive optimization variables are required by Eq.(3).
        w=np.maximum(w,self.dfloor);w/=w.sum();initial_w=w.copy()
        scale=max(float(np.std(y,ddof=0)),self.sfloor)
        # Population/sample std changes objective by a common scalar only.
        previous=None;truth=None;status='max_iter';singular=False
        for iteration in range(1,self.max_iter+1):
            g=-np.log(np.clip(w,np.finfo(float).tiny,1.))
            truth=weighted_median(y,g)  # Eq.(11) with the paper's absolute distance.
            distance=np.abs(y-truth)/scale
            singular|=bool(np.any(distance<self.dfloor))
            stable_d=np.maximum(distance,self.dfloor)
            # KKT solution of min -sum d_i log(w_i), sum w_i=1, Eq.(12).
            w=stable_d/stable_d.sum()
            relative=np.inf if previous is None else abs(truth-previous)/max(abs(truth),self.sfloor)
            if relative<self.tol:
                status='converged';break
            previous=truth
        g=-np.log(np.clip(w,np.finfo(float).tiny,1.))
        contribution=g*(np.abs(y-truth)/scale)
        if contribution.sum()<=self.sfloor:
            loss_share=np.ones(self.n)/self.n
            award=np.ones(self.n)/self.n
            singular=True
        else:
            loss_share=contribution/contribution.sum()
            inverse=1./np.maximum(loss_share,self.lfloor)
            award=inverse/inverse.sum()
        self.reputation=self.decay*self.reputation+self.reward_total*award
        self.round+=1
        return dict(truth=float(truth),weights=g/g.sum(),optimization_weights=w,
                    initial_optimization_weights=initial_w,
                    initial_truth_coefficients=(-np.log(initial_w))/(-np.log(initial_w)).sum(),
                    loss_share=loss_share,award=award,reputation_before=old_rep,
                    reputation=self.reputation.copy(),iterations=iteration,status=status,
                    singular_distance_regularized=singular,round=self.round,
                    scope='scalar_absolute_loss_g_negative_log_fixed_participation')
    predict=step


def self_check():
    y=np.array([0.,1.,2.,5.]);w=np.array([.1,.2,.3,.4]);g=-np.log(w)
    m=weighted_median(y,g)
    costs=np.array([np.dot(g,np.abs(y-v)) for v in y])
    assert np.dot(g,np.abs(y-m))<=costs.min()+1e-12
    d=np.array([.2,.5,1.,2.]);opt=d/d.sum()
    rng=np.random.default_rng(84)
    random_w=rng.dirichlet(np.ones(4),1000)
    optimum=float(-d@np.log(opt))
    assert np.all(-(np.log(random_w)@d)>=optimum-1e-12)
    st=LongTermScalarState(4)
    a=st.step(y);old=st.reputation.copy();b=st.step(y+.1)
    assert np.isclose(b['weights'].sum(),1.)
    assert np.allclose(st.reputation,.99*old+b['award'])
    assert np.isclose(st.reputation.sum(),1.99)
    return dict(weighted_absolute_minimizer=m,kkt_weight_solution=opt.tolist(),
                reputation_mass_after_two_rounds=float(st.reputation.sum()),
                first_result=float(a['truth']),second_result=float(b['truth']),
                singularity_guard_used=bool(a['singular_distance_regularized']))


if __name__=='__main__':
    import json
    print(json.dumps(self_check(),indent=2))
