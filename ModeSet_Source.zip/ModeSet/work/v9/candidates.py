"""V9 alternatives. Inputs are reports and returned reference values, never truth."""
from pathlib import Path
import sys
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'v8'))
from methods import Method

def supported_intervals(y,modes,radii,required):
    events={}
    for i in range(len(y)):
        ints=sorted((float(y[i]-b-radii[i]),float(y[i]-b+radii[i])) for b in modes[i] if np.isfinite(b))
        merged=[]
        for lo,hi in ints:
            if merged and lo<=merged[-1][1]:merged[-1][1]=max(merged[-1][1],hi)
            else:merged.append([lo,hi])
        for lo,hi in merged:
            events.setdefault(lo,[0,0])[0]+=1;events.setdefault(hi,[0,0])[1]+=1
    points=sorted(events);count=0;pieces=[]
    for k,x in enumerate(points):
        count+=events[x][0]
        if count>=required:pieces.append((x,x))
        count-=events[x][1]
        if k+1<len(points) and count>=required:pieces.append((x,points[k+1]))
    return (min(x[0] for x in pieces),max(x[1] for x in pieces)) if pieces else None

class Candidate:
    def __init__(self,name,cal,c,p,seed=0,cal_y=None,cal_v=None,**params):
        self.name=name;self.c=c;self.N=c.N;self.J=c.J;self.params=params
        self.scale=np.maximum(.06,1.4826*np.median(abs(cal-np.median(cal,axis=0)),axis=0))
        self.init=np.median(cal,axis=0);self.q=np.maximum(.003,np.mean(cal*cal,axis=0))
        self.hist={};self.anchors=[None]*c.J;self.seq=0
        self.modes=np.full((c.N,int(params.get('modes',5))),np.nan);self.modes[:,0]=self.init
        self.count=np.zeros_like(self.modes);self.count[:,0]=len(cal)
        self.stamp=np.zeros_like(self.modes);self.last=np.zeros(c.N,int)
        self.bank=[x.copy() for x in cal[-min(120,len(cal)):]]
        self.last_res=self.init.copy()
        if params.get('common_scale',False):self.scale[:]=np.median(self.scale)
        if name.startswith('Legacy:'):
            self.base=Method(name.split(':',1)[1],cal,c,p,seed)
            if 'rate' in params:self.base.model.rate=params['rate']
        else:self.base=None
    def initialize_history(self,cal_history,audits,refs,warm,delay):
        if self.base:return
        self.hist={t:y.copy() for t,y in enumerate(cal_history)}
        for j in range(self.J):
            ids=[t for t in range(warm) if t+delay<=warm and audits[t,j]]
            if ids:
                s=ids[-1];self.anchors[j]=(s,float(refs[s,j]))
    def predict(self,y,commit=False,t=None):
        if self.base:return self.base.predict(y,commit=commit,t=t)
        if t is None:t=max(self.hist,default=-1)+1
        J,N=y.shape;z=y.copy();w=np.full_like(y,1/N);selected=np.zeros((J,N),int)
        if self.name in ['DeltaAnchor','BlockAnchor','ChordAnchor','LatestMean','LastReference']:
            out=np.zeros(J)
            for j in range(J):
                anchor=self.anchors[j]
                if anchor is None:out[j]=np.median(y[j]-self.init);continue
                s,value=anchor
                if self.name=='LastReference':out[j]=value;continue
                if self.name=='LatestMean':out[j]=value+np.mean(y[j]-self.hist[s][j]);continue
                step=1 if self.name=='DeltaAnchor' else int(self.params.get('block',4)) if self.name=='BlockAnchor' else t-s
                pos=s;v=value
                while pos<t:
                    nxt=min(t,pos+max(1,step));end=y[j] if nxt==t else self.hist[nxt][j]
                    v+=np.median(end-self.hist[pos][j]);pos=nxt
                out[j]=v
        elif self.name in ['ContrastKNN','PatternMemory']:
            bank=np.array(self.bank);ww=1/self.q;ww/=ww.sum()
            out=[]
            bc=bank-(bank@ww)[:,None]
            for j in range(J):
                center=y[j]@ww;contrast=y[j]-center
                dist=np.mean(((bc-contrast)/self.scale)**2,axis=1)
                k=1 if self.name=='PatternMemory' else int(self.params.get('neighbors',8))
                ids=np.argsort(dist)[:min(k,len(dist))]
                bw=1/(.1+dist[ids]);bw/=bw.sum();bias=bw@bank[ids]
                z[j]=y[j]-bias;w[j]=ww;out.append(z[j]@ww)
            out=np.array(out)
        elif self.name in ['ModeMAP','ModeSupport','ModeBayes','ModeMedian','ModeSet']:
            out=[];valid=np.isfinite(self.modes);mm=np.nan_to_num(self.modes)
            for j in range(J):
                grid=(y[j,:,None]-mm)[valid]
                # Each candidate common truth induces the best local audited bias state.
                dist=abs(y[j][None,:,None]-grid[:,None,None]-mm[None,:,:])/self.scale[None,:,None]
                dist=np.where(valid[None,:,:],dist,np.inf)
                loc=np.argmin(dist,axis=2);res=np.min(dist,axis=2)
                cap=float(self.params.get('cap',16.))
                if self.name=='ModeBayes':
                    pr=np.where(valid,(self.count+1)**float(self.params.get('prior_power',.5)),0.);pr/=pr.sum(axis=1,keepdims=True)
                    logp=-.5*dist*dist+np.log(np.maximum(pr,1e-300))[None,:,:]
                    vmax=np.max(logp,axis=2)
                    nll=-2*(vmax+np.log(np.exp(logp-vmax[:,:,None]).sum(axis=2)))
                    score=np.minimum(nll,cap).sum(axis=1)
                elif self.name in ['ModeMAP','ModeMedian','ModeSet']:score=np.sum(np.minimum(res*res,cap),axis=1)
                else:score=-np.sum(res<=float(self.params.get('width',2.5)),axis=1)+.01*np.mean(np.minimum(res*res,16.),axis=1)
                idx=int(np.argmin(score));x=grid[idx];chosen=loc[idx]
                # Refine inside the chosen combination with bounded influence.
                for _ in range(2):
                    corrected=y[j]-mm[np.arange(N),chosen]
                    robust=1/np.maximum(1,abs(corrected-x)/(2*self.scale))
                    ww=robust/(self.scale*self.scale);ww/=ww.sum();x=corrected@ww
                    if self.name in ['ModeMedian','ModeSet']:
                        x=float(np.median(corrected));ii=np.argsort(corrected)[[(N-1)//2,N//2]];ww=np.zeros(N)
                        for i in ii:ww[i]+=.5
                    dd=abs(y[j,:,None]-x-mm)/self.scale[:,None]
                    chosen=np.argmin(np.where(valid,dd,np.inf),axis=1)
                z[j]=y[j]-mm[np.arange(N),chosen];w[j]=ww;out.append(z[j]@ww);selected[j]=chosen
            out=np.array(out)
            if self.name=='ModeSet':
                iv=[];required=int(np.ceil(float(self.params.get('coverage',.75))*N))
                for j in range(J):
                    bounds=supported_intervals(y[j],self.modes,float(self.params.get('width',1.5))*self.scale,required)
                    if bounds is not None:out[j]=(bounds[0]+bounds[1])/2
                    iv.append(bounds if bounds is not None else (np.nan,np.nan))
        else:raise ValueError(self.name)
        packet=dict(y=y.copy(),out=out.copy(),z=z.copy(),w=w.copy(),q=self.q.copy(),selected=selected)
        if self.name=='ModeSet':packet['intervals']=np.array(iv)
        if commit:self.hist[t]=y.copy();self.seq+=1
        return out,packet
    def audit(self,t,packet,v,mask):
        if self.base:
            if 'forget' not in self.params:return self.base.audit(t,packet,v,mask)
            for j in np.flatnonzero(mask):
                y=packet['y'][j];forget=float(self.params['forget'])
                if self.name=='Legacy:RLS':
                    mo=self.base.model;X=np.column_stack([y,np.ones(self.N)]);P=mo.P/forget;PX=np.einsum('nij,nj->ni',P,X)
                    K=PX/(1+np.einsum('ni,ni->n',X,PX))[:,None]
                    mo.theta+=K*(v[j]-np.einsum('ni,ni->n',mo.theta,X))[:,None];mo.P=P-np.einsum('ni,nj->nij',K,PX)
                    mo.q=(1-mo.rate)*mo.q+mo.rate*np.clip((packet['extras'][j]-v[j])**2,.003,4.)
                elif self.name=='Legacy:JointRLS':
                    X=np.r_[y,1.];P=self.base.jP/forget;PX=P@X;K=PX/(1+X@PX)
                    self.base.jtheta+=K*(v[j]-X@self.base.jtheta);self.base.jP=P-np.outer(K,PX)
                else:raise ValueError('forget only valid for RLS')
            return
        for j in np.flatnonzero(mask):
            self.anchors[j]=(t,float(v[j]));r=packet['y'][j]-v[j];self.last_res=r.copy()
            if self.name in ['PatternMemory','ContrastKNN']:
                self.bank.append(r.copy());self.bank=self.bank[-int(self.params.get('memory',256)):]
            if self.name.startswith('Mode'):
                for i in range(self.N):
                    valid=np.isfinite(self.modes[i]);dist=np.where(valid,abs(self.modes[i]-r[i]),np.inf);k=int(np.argmin(dist))
                    if dist[k]>float(self.params.get('threshold',3.))*self.scale[i]:
                        empty=np.flatnonzero(~valid)
                        k=int(empty[0]) if len(empty) else int(np.argmin(self.stamp[i,1:])+1)
                        self.modes[i,k]=r[i];self.count[i,k]=1
                    else:
                        rate=float(self.params.get('rate',.15));self.modes[i,k]=(1-rate)*self.modes[i,k]+rate*r[i];self.count[i,k]+=1
                    self.stamp[i,k]=self.seq
