"""Standard temporal kernels and an explicitly adapted sparse-bias baseline.

DynaTD follows Li et al., KDD 2015, Equations 11/12 and Algorithm 1.
AuditTV is OUR DRS-inspired augmented-bias adaptation, not a replication of
Farahmand et al. TSP 2011. Neither implementation claims a safety guarantee.
Only returned audit() calls expose references to AuditTV. Query predictions
do not mutate the learner. All numerical adaptation defaults are recorded.
"""
from __future__ import annotations

import numpy as np


def _difference(length):
    d = np.zeros((max(0, length - 1), length))
    if length > 1:
        ii = np.arange(length - 1)
        d[ii, ii] = -1.
        d[ii, ii + 1] = 1.
    return d


def audit_tv_solve(y, known, refs, *, lam=.2, rho=1., boundary_mean=0.,
                   boundary_strength=1e-6, initial=None, max_iter=300,
                   abs_tol=1e-5, rel_tol=1e-4):
    """Solve a single task's window (time x sources) by two-block ADMM.

    f(B) = .5||P(Y-B)||_F^2
           + N/2 sum_t known_t (mean(Y_t)-ref_t-mean(B_t))^2
           + lam ||D B||_1.

    P centers each row. If there is no returned anchor in the window, add
    N*boundary_strength/2 * (mean(B_0)-boundary_mean)^2. This only fixes an
    otherwise unidentifiable common bias offset; it is a state prior, not a
    reference observation. Return residuals and convergence status explicitly.
    """
    y = np.asarray(y, float)
    known = np.asarray(known, bool)
    refs = np.asarray(refs, float)
    if y.ndim != 2 or not len(y) or y.shape[1] == 0:
        raise ValueError('y must be a nonempty time-by-source matrix')
    length, n = y.shape
    if known.shape != (length,) or refs.shape != (length,):
        raise ValueError('known and refs must match window length')
    if not np.isfinite(y).all() or not np.isfinite(refs[known]).all():
        raise ValueError('reports and revealed references must be finite')
    if lam < 0 or rho <= 0 or boundary_strength <= 0 or max_iter < 1:
        raise ValueError('invalid optimization parameters')
    d = _difference(length)
    gram = d.T @ d
    ym = y.mean(axis=1)
    yc = y - ym[:, None]
    q = known.astype(float)
    mean_target = np.zeros(length)
    mean_target[known] = ym[known] - refs[known]
    eps = float(boundary_strength) if not known.any() else 0.
    ac = np.eye(length) + rho * gram
    am = np.diag(q) + rho * gram
    am[0, 0] += eps
    rhs_mean = mean_target.copy()
    rhs_mean[0] += eps * boundary_mean
    # The small dense inverses are computed once per solve, not per ADMM step.
    # They are deterministic and make multiple-source right-hand sides cheap.
    ic = np.linalg.solve(ac, np.eye(length))
    im = np.linalg.solve(am, np.eye(length))
    if initial is None:
        b = np.full_like(y, boundary_mean)
    else:
        b = np.array(initial, dtype=float, copy=True)
        if b.shape != y.shape or not np.isfinite(b).all():
            raise ValueError('initial must be finite and match y')
    z = d @ b
    u = np.zeros_like(z)
    converged = False
    primal = dual = ep = ed = 0.
    for iteration in range(1, int(max_iter) + 1):
        v = z - u
        vm = v.mean(axis=1) if len(v) else np.zeros(0)
        vc = v - vm[:, None]
        bc = ic @ (yc + rho * d.T @ vc)
        bm = im @ (rhs_mean + rho * d.T @ vm)
        b = bc + bm[:, None]
        db = d @ b
        zold = z.copy()
        a = db + u
        z = np.sign(a) * np.maximum(abs(a) - lam / rho, 0.)
        u += db - z
        primal = float(np.linalg.norm(db - z))
        dual = float(rho * np.linalg.norm(d.T @ (z - zold)))
        ep = float(np.sqrt(z.size) * abs_tol + rel_tol * max(np.linalg.norm(db), np.linalg.norm(z)))
        ed = float(np.sqrt(b.size) * abs_tol + rel_tol * np.linalg.norm(rho * d.T @ u))
        if primal <= ep and dual <= ed:
            converged = True
            break
    bm = b.mean(axis=1)
    centered_residual = (y - b) - (ym - bm)[:, None]
    mean_residual = np.zeros(length)
    mean_residual[known] = bm[known] - mean_target[known]
    grad = -centered_residual + mean_residual[:, None]
    grad[0] += eps * (bm[0] - boundary_mean)
    objective = (.5 * np.sum(centered_residual ** 2)
                 + .5 * n * np.sum(mean_residual ** 2)
                 + lam * np.sum(abs(d @ b))
                 + .5 * n * eps * (bm[0] - boundary_mean) ** 2)
    scaled_dual = rho * u
    sg = np.maximum(abs(scaled_dual) - lam, 0.)
    nonzero = abs(z) > 1e-10
    if nonzero.any():
        sg[nonzero] = abs(scaled_dual[nonzero] - lam * np.sign(z[nonzero]))
    info = dict(iterations=iteration, converged=bool(converged),
                primal_residual=primal, dual_residual=dual,
                primal_tolerance=ep, dual_tolerance=ed,
                stationarity_norm=float(np.linalg.norm(grad + d.T @ scaled_dual)),
                z_subgradient_violation=float(sg.max()) if sg.size else 0.,
                objective=float(objective), returned_anchor_count=int(known.sum()),
                uses_boundary_state_prior=bool(eps), boundary_strength=eps,
                window_length=length, lam=float(lam), rho=float(rho))
    return b, info


class DynaTD:
    """Full-participation temporal numerical kernel, not a privacy protocol."""
    def __init__(self, cal, c, p, seed=0, **params):
        self.name = 'DynaTD'
        self.c = c
        self.N, self.J = c.N, c.J
        self.alpha = float(params.get('alpha', 2.))
        self.beta = float(params.get('beta', 1.))
        self.theta = float(params.get('theta', 1.))
        self.gamma = float(params.get('gamma', .98))
        self.smooth = float(params.get('smooth', params.get('lam', 1.)))
        if self.alpha <= 1 or self.beta <= 0 or self.theta <= 0 or not 0 < self.gamma <= 1 or self.smooth < 0:
            raise ValueError('invalid DynaTD parameters')
        self.count = np.zeros(self.N)
        self.error = np.zeros(self.N)
        self.prev = None
        self.seq = 0

    def initialize_history(self, cal_history, audits, refs, warm, delay):
        # Deliberately no reference use: original DynaTD is unsupervised.
        for t, y in enumerate(np.asarray(cal_history)[:warm]):
            self.predict(y, commit=True, t=t)

    def predict(self, y, commit=False, t=None):
        y = np.asarray(y, float)
        if y.shape != (self.J, self.N):
            raise ValueError('unexpected report shape')
        precision = (2 * self.alpha - 2 + self.count) / (2 * self.beta + self.theta * self.error)
        pseudo = self.smooth if self.prev is not None else 0.
        denominator = precision.sum() + pseudo
        out = y @ precision
        if pseudo:
            out = out + pseudo * self.prev
        out = out / denominator
        w = np.broadcast_to(precision / denominator, y.shape).copy()
        packet = dict(y=y.copy(), z=y.copy(), w=w, q=precision.copy(),
                      out=out.copy(), pseudo_source_share=float(pseudo / denominator),
                      diagnostics=dict(gamma=self.gamma, smooth=self.smooth,
                                       source_share_sum=float(precision.sum() / denominator)))
        if commit:
            self.count = self.gamma * self.count + self.J
            self.error = self.gamma * self.error + np.sum((y - out[:, None]) ** 2, axis=0)
            self.prev = out.copy()
            self.seq += 1
        return out, packet

    def audit(self, t, packet, v, mask):
        return None


class AuditTV:
    """Causal windowed sparse-bias adaptation inspired by DRS, not author code."""
    def __init__(self, cal, c, p, seed=0, **params):
        self.name = 'AuditTV'
        self.c = c
        self.N, self.J = c.N, c.J
        self.window = int(params.get('window', 32))
        self.lam = float(params.get('lam', .2))
        self.rho = float(params.get('rho', 1.))
        self.max_iter = int(params.get('max_iter', 300))
        self.abs_tol = float(params.get('abs_tol', 1e-5))
        self.rel_tol = float(params.get('rel_tol', 1e-4))
        self.boundary_strength = float(params.get('boundary_strength', 1e-6))
        if self.window < 1:
            raise ValueError('window must be positive')
        self.initial_bias = np.mean(np.asarray(cal, float), axis=0)
        self.hist = {}
        self.anchors = {}
        self.bias_cache = {}
        self.seq = 0
        self.last_diagnostics = []

    def initialize_history(self, cal_history, audits, refs, warm, delay):
        history = np.asarray(cal_history, float)
        first = max(0, min(warm, len(history)) - self.window)
        for t in range(first, min(warm, len(history))):
            self.hist[t] = history[t].copy()
            self.bias_cache[t] = np.broadcast_to(self.initial_bias, (self.J, self.N)).copy()
            if t + delay <= warm:
                for j in np.flatnonzero(audits[t]):
                    self.anchors[(t, int(j))] = float(refs[t, j])

    def predict(self, y, commit=False, t=None):
        y = np.asarray(y, float)
        if y.shape != (self.J, self.N):
            raise ValueError('unexpected report shape')
        if t is None:
            t = max(self.hist, default=-1) + 1
        # The strictly earlier filter also prevents accidental reuse of current
        # candidate packets from another query in the white-box attacker search.
        ids = sorted(k for k in self.hist if k < t)[-(self.window - 1):] if self.window > 1 else []
        ids.append(t)
        ys = np.stack([y if k == t else self.hist[k] for k in ids])
        bs = np.empty_like(ys)
        diagnostics = []
        for j in range(self.J):
            known = np.array([(k, j) in self.anchors for k in ids])
            references = np.array([self.anchors.get((k, j), 0.) for k in ids])
            init = np.stack([self.bias_cache[k][j] if k in self.bias_cache else self.initial_bias for k in ids])
            # A previous fitted state fixes only the common additive gauge when
            # this window has no returned references. It is not a gold label.
            boundary_mean = float(init[0].mean())
            b, info = audit_tv_solve(ys[:, j], known, references, lam=self.lam,
                                     rho=self.rho, boundary_mean=boundary_mean,
                                     boundary_strength=self.boundary_strength,
                                     initial=init, max_iter=self.max_iter,
                                     abs_tol=self.abs_tol, rel_tol=self.rel_tol)
            bs[:, j] = b
            info['task'] = j
            diagnostics.append(info)
        z = y - bs[-1]
        out = z.mean(axis=1)
        packet = dict(y=y.copy(), z=z.copy(), w=np.full_like(y, 1 / self.N),
                      q=np.ones(self.N), out=out.copy(), diagnostics=diagnostics)
        if commit:
            self.hist[t] = y.copy()
            self.bias_cache.update({k: bs[h].copy() for h, k in enumerate(ids)})
            keep = set(ids)
            self.hist = {k: value for k, value in self.hist.items() if k in keep}
            self.bias_cache = {k: value for k, value in self.bias_cache.items() if k in keep}
            self.anchors = {key: value for key, value in self.anchors.items() if key[0] in keep}
            self.last_diagnostics = diagnostics
            self.seq += 1
        return out, packet

    def audit(self, t, packet, v, mask):
        # Store only references explicitly delivered by the experiment driver.
        # Expired references cannot repair an already released prediction.
        if t not in self.hist:
            return None
        for j in np.flatnonzero(mask):
            self.anchors[(int(t), int(j))] = float(v[j])


class TemporalBaseline:
    """Name-based adapter matching Candidate(name,cal,c,p,seed,**params)."""
    def __init__(self, name, cal, c, p, seed=0, **params):
        cls = DynaTD if name == 'DynaTD' else AuditTV if name == 'AuditTV' else None
        if cls is None:
            raise ValueError(name)
        self.base = cls(cal, c, p, seed, **params)

    def initialize_history(self, *args, **kwargs):
        return self.base.initialize_history(*args, **kwargs)

    def predict(self, *args, **kwargs):
        return self.base.predict(*args, **kwargs)

    def audit(self, *args, **kwargs):
        return self.base.audit(*args, **kwargs)
