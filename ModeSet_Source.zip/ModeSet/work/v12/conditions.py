"""Additional condition and second sensor-dataset evaluation. No model retuning."""
from pathlib import Path
import json,hashlib,copy,importlib.util
import numpy as np
from concurrent.futures import ProcessPoolExecutor,as_completed
BASE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('v12_conditions_ex',BASE/'experiment.py');ex=importlib.util.module_from_spec(spec);spec.loader.exec_module(ex)
CACHE={};original=ex.data
def gas_stream(batch):
    if batch in CACHE:return CACHE[batch]
    def load(k):
        x=[];y=[]
        for line in (BASE.parent/f'v7/gas/batch{k}.dat').read_text().splitlines():
            a=line.split();g,v=a[0].split(';')
            if g=='1':x.append([float(s.split(':')[1]) for s in a[1:]]);y.append(float(v))
        return np.array(x).reshape(-1,16,8),np.array(y)
    X,v=load(1);C,w=load(2);Y,u=load(batch);center=v.mean();sd=v.std();xx=np.sign(X)*np.log1p(abs(X));mu=xx.mean(axis=0);scale=np.maximum(xx.std(axis=0),.001);xx=(xx-mu)/scale
    def pred(Z):
        zz=(np.sign(Z)*np.log1p(abs(Z))-mu)/scale;out=[]
        for i in range(16):
            A=np.c_[np.ones(len(X)),xx[:,i]];B=np.c_[np.ones(len(Z)),zz[:,i]];pen=np.eye(9);pen[0,0]=0.;coef=np.linalg.solve(A.T@A+pen,A.T@v);out.append((B@coef-center)/sd)
        return np.array(out).T
    CACHE[batch]=(np.r_[pred(C),pred(Y)],np.r_[(w-center)/sd,(u-center)/sd],len(w),dict(fit_batch=1,warm_batch=2,test_batch=batch,gas_label=1,fit_count=len(v),warm_count=len(w),target_scale=float(sd),physical_data='real_gas_reports_with_injected_attacks',chronology='row order is an experimental sequence, not uniformly timed natural dynamics'))
    return CACHE[batch]
def make(case,seed):
    if not case['ds'].startswith('gas'):return original(case,seed)
    batch=int(case['ds'][-1]);clean,x,warm,meta=gas_stream(batch);clean=clean.copy();x=x.copy();meta=copy.deepcopy(meta);rng=np.random.default_rng(seed);N=16;learn=120;start=warm+learn;n=len(x);T=n-start;delay=2
    bad=np.argsort(np.mean((clean[:warm-delay+1]-x[:warm-delay+1,None])**2,axis=0))[:12];pools=[];seen=set()
    while len(pools)<48:
        z=tuple(sorted(rng.choice(12,9,False).tolist()))
        if z not in seen:seen.add(z);pools.append(z)
    pattern=np.zeros((n,N),int)
    for a,b,pool in [(warm,start,pools[:24]),(start,n,pools[24:])]:
        t=a
        while t<b:
            leng=int(rng.integers(1,9));idx=bad[list(pool[int(rng.integers(len(pool)))])];pattern[t:min(t+leng,b),idx]=1;t+=leng
    if case['scene']=='clean':pattern[:]=0
    y=clean.copy();y[:,bad]+=pattern[:,bad]*(1.5+np.linspace(-.55,.55,12));audit=np.ones(n,bool);audit[warm:start]=rng.random(learn)<.25;audit[start:]=rng.random(T)<case['p'];observed=np.flatnonzero(audit&(np.arange(n)+delay<=start))
    meta.update(joint_overlap=len({tuple(a) for a in pattern[warm:start]}&{tuple(a) for a in pattern[start:]}),each_active_source_audited=all(any(pattern[t,i] for t in observed) for i in bad) if case['scene']!='clean' else True,learning_rounds=learn)
    return dict(y=y,clean=clean,x=x,ref=x.copy(),audit=audit,N=N,T=T,warm=warm,start=start,delay=delay,reference_error=0.,pattern=pattern,bad=bad,meta=meta)
ex.data=make
def run(j):return ex.run(j)
def main():
    base=dict(ds='syn',scene='unseen',p=.25)
    cs=[{**base,'jitter':v} for v in [0.,.05,.1,.2,.35,.5]]+[{**base,'drift':v} for v in [.03,.06,.12,.24]]+[{**base,'p':0.,'novel':v} for v in [2,6,12]]+[{**base,'p':.1,'delay':d} for d in [2,10]]
    cs += [dict(ds='gas'+str(b),scene=s,p=p) for b in [3,7] for s,p in [('unseen',0.),('unseen',.25),('clean',.25)]]
    cfg=[q for q in ex.configs() if q[0] in ['ModeSet','ModeMAP','JointTemplate','BoxMode','WarmJoint','StableJoint','ContrastKNN','AuditTV']];seeds=list(range(74100,74106));jobs=[(c,s,m,p) for c in cs for s in seeds for m,p in cfg]
    out=BASE/'conditions';out.mkdir(exist_ok=True);hashes={str(f.relative_to(BASE.parent)):hashlib.sha256(f.read_bytes()).hexdigest() for f in [Path(__file__),BASE/'experiment.py',BASE.parent/'v11/data.py',BASE.parent/'v9/candidates.py']};(out/'frozen.json').write_text(json.dumps(dict(jobs=jobs,count=len(jobs),hashes=hashes,purpose='condition tests and second real-report dataset; frozen existing model parameters'),indent=2));rows=[]
    with ProcessPoolExecutor(max_workers=3) as pool:
        for f in as_completed([pool.submit(run,j) for j in jobs]):
            rows.append(f.result())
            if len(rows)%40==0:print('conditions',len(rows),'/',len(jobs),flush=True)
    (out/'runs.json').write_text(json.dumps(rows,allow_nan=False))
    for n,h in hashes.items():assert hashlib.sha256((BASE.parent/n).read_bytes()).hexdigest()==h
    print('DONE',len(rows),flush=True)
if __name__=='__main__':main()
