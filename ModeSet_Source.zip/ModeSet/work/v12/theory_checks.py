from pathlib import Path
import json
import numpy as np
import experiment as ex
BASE=Path(__file__).resolve().parent
def main():
    rng=np.random.default_rng(73200);N=8;K=4;E=.012;tau=.24;beta=np.arange(K)[None,:]*np.linspace(.8,1.1,N)[:,None];c=ex.SimpleNamespace(N=N,J=1,G=N,warm=30,T=400,delay=3,reference_error=.002);cal=rng.uniform(-.01,.01,(30,N));m=ex.Candidate('ModeSet',cal,c,.25,1,threshold=4.,width=2.,coverage=.875);seen=np.zeros((N,K),bool);seen[:,0]=True;pending=[];max_error=0.;matched=0
    for t in range(400):
        for ot,states,res in pending:
            if ot+c.delay==t:
                m.audit(ot,dict(y=res[None,:]),np.array([0.]),np.array([True]));seen[np.arange(N),states]=True
        pending=[a for a in pending if a[0]+c.delay>t];states=rng.integers(0,K,N);res=beta[np.arange(N),states]+rng.uniform(-E,E,N)
        if rng.random()<.25:pending.append((t,states.copy(),res.copy()))
        m.seq=t
        for i,k in zip(*np.nonzero(seen)):
            err=float(np.nanmin(abs(m.modes[i]-beta[i,k])));max_error=max(max_error,err);assert err<=E+1e-12;matched+=1
    assert np.isfinite(m.modes).sum()==N*K
    # Upper bound on unlearned state exposures under predictable coordinated choices.
    probes=[];S=8;T=500;trials=1000
    for q in [.1,.25,.5]:
        for delay in [2,10]:
            counts=[];over=0;delta=.05;mm=int(np.ceil(np.log(S/delta)/(-np.log(1-q))))
            for rep in range(trials):
                known=np.zeros(S,bool);pending=[];U=0
                for t in range(T):
                    for at,ids in pending:
                        if at==t:known[ids]=True
                    pending=[a for a in pending if a[0]>t]
                    # Choose using past returned labels, before this round's audit coin.
                    unknown=np.flatnonzero(~known);ids=unknown[:2] if len(unknown) else rng.choice(S,2,False)
                    if not known[ids].all():U+=1
                    if rng.random()<q:pending.append((t+delay,ids.copy()))
                counts.append(U);over+=U>S*(mm+delay)
            probes.append(dict(q=q,delay=delay,trials=trials,mean_unlearned_rounds=float(np.mean(counts)),expected_upper=S*(1/q+delay),high_probability_upper=S*(mm+delay),observed_exceedance=over/trials,delta=delta))
    # Two-world worst-case loss with a completely learned identical dictionary.
    cc=ex.SimpleNamespace(N=5,J=1);cal=np.zeros((20,5));worlds=[]
    for name in ['ModeSet','ModeMAP']:
        mo=ex.Candidate(name,cal,cc,.25,0,threshold=4.,width=2.,coverage=1.);mo.modes[:,:2]=np.array([0.,1.]);estimate=float(mo.predict(np.ones((1,5)))[0][0]);worlds.append(dict(method=name,estimate=estimate,truths=[0.,1.],worst_absolute_loss=max(abs(estimate),abs(estimate-1.))))
    assert abs(worlds[0]['worst_absolute_loss']-.5)<1e-12
    out=dict(state_assignment_checks=matched,max_center_error=max_error,error_bound=E,audit_exposure_probes=probes,two_world=worlds,scope='Deterministic separated finite states; sufficient capacity; independent audit coins; bounded residual error. Empirical MAD intervals are not assigned unconditional confidence.',pass_all=True)
    (BASE/'theory_checks.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
if __name__=='__main__':main()
