from pathlib import Path
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1');os.environ.setdefault('OMP_NUM_THREADS','1')
import sys,json,copy,time,hashlib,argparse,importlib.util,math,platform
from concurrent.futures import ProcessPoolExecutor,as_completed
from types import SimpleNamespace
import numpy as np
BASE=Path(__file__).resolve().parent;WORK=BASE.parent
def module(name,path):
    s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
sys.path.insert(0,str(WORK/'v11'));v11=module('v12_prior_data',WORK/'v11/data.py');st=module('v12_prior_study',WORK/'v11/study.py');sb=module('v12_stable',WORK/'v11/stable.py')
from candidates import Candidate,supported_intervals
from temporal_baselines import TemporalBaseline
sys.path.insert(0,str(WORK/'v6'))
from baselines.mdm_cpdz import CPDZSharedAuditAdaptation,MDMOptimizedTruthFinder
from baselines.prtd_vrpmtd import VRPMTDScalarState

class SingleState(Candidate):
    def __init__(self,name,cal,c,p,seed=0,**params):super().__init__('ModeSet',cal,c,p,seed,modes=1,**params)
    def audit(self,t,p,v,mask):
        for j in np.flatnonzero(mask):self.modes[:,0]=.85*self.modes[:,0]+.15*(p['y'][j]-v[j])

class JointTemplate(Candidate):
    def __init__(self,name,cal,c,p,seed=0,**params):
        super().__init__('ModeSet',cal,c,p,seed,**params);self.templates=[tuple(np.zeros(c.N,dtype=int))]
    def audit(self,t,p,v,mask):
        before=self.modes.copy();super().audit(t,p,v,mask)
        # Drop templates touching a newly assigned/replaced state.
        changed=(~np.isfinite(before)&np.isfinite(self.modes))|(np.isfinite(before)&(abs(self.modes-before)>self.params.get('threshold',4.)*self.scale[:,None]))
        self.templates=[a for a in self.templates if not any(changed[i,k] for i,k in enumerate(a))]
        for j in np.flatnonzero(mask):
            dist=abs(self.modes-(p['y'][j]-v[j])[:,None]);pat=tuple(np.argmin(np.where(np.isfinite(dist),dist,np.inf),axis=1).tolist())
            if pat not in self.templates:self.templates.append(pat)
        self.templates=self.templates[-256:]
    def predict(self,y,commit=False,t=None):
        out=[];ivs=[];zs=[]
        for yy in y:
            best=None;cost=np.inf;pieces=[]
            for pat in self.templates:
                mu=self.modes[np.arange(self.N),pat]
                if not np.isfinite(mu).all():continue
                z=yy-mu;x=np.median(z);s=float(np.minimum(((z-x)/self.scale)**2,16.).sum())
                if s<cost:best=x,z;cost=s
                iv=supported_intervals(yy,mu[:,None],2*self.scale,int(np.ceil(.875*self.N)))
                if iv:pieces.append(iv)
            if best is None:best=float(np.median(yy-self.init)),yy-self.init
            iv=(min(p[0] for p in pieces),max(p[1] for p in pieces)) if pieces else (np.nan,np.nan)
            out.append(.5*(iv[0]+iv[1]) if pieces else best[0]);ivs.append(iv);zs.append(best[1])
        if commit:self.seq+=1
        a=np.array(out);return a,dict(y=y.copy(),z=np.array(zs),out=a.copy(),w=np.full_like(y,1/self.N),q=self.q.copy(),intervals=np.array(ivs))

class Recent:
    def __init__(self,name,cal,c,p,seed=0,**params):
        self.name=name;self.c=c;self.core=None;self.seq=0
        if name=='CPDZ-A':
            self.core=CPDZSharedAuditAdaptation(c.N,delta=.25,seed=seed);self.core.alpha=1+(cal*cal<=.25).sum(axis=0);self.core.beta=1+(cal*cal>.25).sum(axis=0)
        elif name=='MDM-core':self.core=MDMOptimizedTruthFinder(c.N)
    def initialize_history(self,y,audits,refs,warm,delay):
        if self.name=='VRPM-A':
            scale=max(.1,float(np.quantile(y,.95)-np.quantile(y,.05)));self.core=VRPMTDScalarState(self.c.N,xi=.001,scale=scale,update_mode='absolute')
            for row in y:self.core.step(row[0])
        elif self.name=='MDM-core':
            for t,row in enumerate(y):self.core.predict(row.T,t)
        self.seq=warm
    def predict(self,y,commit=False,t=None):
        core=self.core if commit else copy.deepcopy(self.core)
        if self.name=='VRPM-A':a=np.array([core.step(y[0])['truth']])
        else:a=core.predict(y.T,self.seq if t is None else t)
        if commit:self.seq+=1
        return a,dict(y=y.copy(),out=a.copy())
    def audit(self,t,p,v,mask):
        if self.name=='CPDZ-A':self.core.update_audit(p['y'].T,v,mask)

def construct(name,cal,c,params,seed):
    if name in ['CPDZ-A','VRPM-A','MDM-core']:return Recent(name,cal,c,.25,seed,**params)
    if name=='SingleState':return SingleState(name,cal,c,.25,seed,**params)
    if name=='JointTemplate':return JointTemplate(name,cal,c,.25,seed,**params)
    if name=='StableJoint':return sb.StableJoint(name,cal,c,.25,seed,**params)
    if name=='DynaTD':return TemporalBaseline(name,cal,c,.25,seed,**params)
    return st.construct(name,cal,c,params,seed)

def extended(seed,N=16,K=2,p=0.,learn_p=.25,delay=2):
    rng=np.random.default_rng(seed);warm=96;learn=360;T=240;start=warm+learn;n=start+T;tt=np.arange(n)
    x=.6*np.sin(tt/18)+np.cumsum(rng.normal(0,.018,n));x[start+60:]+=1.6;x[start+150:]-=2.3
    C=int(np.ceil(.75*N));bias=rng.uniform(-.08,.08,N);sigma=np.r_[np.full(C,.035),np.full(N-C,.14)];group=rng.uniform(-.018,.018,(n,int(np.ceil(N/4)))).repeat(4,axis=1)[:,:N]
    clean=x[:,None]+bias+rng.uniform(-1,1,(n,N))*sigma+group;ref=x+rng.uniform(-.015,.015,n);bad=np.argsort(np.mean((clean[:warm-delay+1]-ref[:warm-delay+1,None])**2,axis=0))[:C];active=int(np.ceil(.75*C))
    all_possible=math.comb(C,active)*(K-1)**active;count=min(24,all_possible//2);pool=[];seen=set()
    while len(pool)<2*count:
        a=np.zeros(C,int);idx=rng.choice(C,active,replace=False);a[idx]=rng.integers(1,K,len(idx));k=tuple(a)
        if k not in seen:pool.append(a);seen.add(k)
    states=np.zeros((n,N),int)
    for lo,hi,patterns in [(warm,start,pool[:count]),(start,n,pool[count:])]:
        t=lo
        while t<hi:
            length=int(rng.integers(1,9));states[t:min(hi,t+length),bad]=patterns[int(rng.integers(len(patterns)))];t+=length
    amp=1.5+np.linspace(-.55,.55,C);y=clean.copy();y[:,bad]+=states[:,bad]*amp
    audit=np.zeros(n,bool);audit[:warm]=True;audit[warm:start]=rng.random(learn)<learn_p;audit[start:]=rng.random(T)<p
    observed=np.flatnonzero(audit&(np.arange(n)+delay<=start));covered=sum(any(states[t,i]==k for t in observed) for i in bad for k in range(K))
    return dict(y=y,clean=clean,x=x,ref=ref,audit=audit,N=N,T=T,warm=warm,start=start,delay=delay,reference_error=.015,pattern=states,bad=bad,meta=dict(N=N,K=K,learning_probability=learn_p,states_covered=covered,states_required=C*K,joint_overlap=len({tuple(x) for x in states[warm:start]}&{tuple(x) for x in states[start:]}),physical_data='synthetic',learning_rounds=learn))

def data(case,seed):
    if case.get('ds')=='extended':return extended(seed,**{k:v for k,v in case.items() if k!='ds'})
    d=v11.make(seed,**case);d['meta']=copy.deepcopy(d['meta']);return d

def run(job,trace=False):
    case,seed,name,params=job;d=data(case,seed);N=d['N'];c=SimpleNamespace(N=N,J=1,G=N,warm=d['warm'],T=d['T'],delay=d['delay'],reference_error=d['reference_error'])
    ids=[t for t in range(c.warm) if d['audit'][t] and t+c.delay<=c.warm];cal=d['y'][ids]-d['ref'][ids,None];model=construct(name,cal,c,params,seed);model.initialize_history(d['y'][:c.warm,None,:],d['audit'][:,None],d['ref'][:,None],c.warm,c.delay)
    # Historical packets in the warm tail need only their observed reports.
    pending=[(t,dict(y=d['y'][t,None,:].copy())) for t in range(c.warm) if t+c.delay>c.warm]
    errors=[];pred=[];ivs=[];switch=[];arrivals=0;learn_arrivals=len(ids);start_clock=time.perf_counter()
    for t in range(c.warm,len(d['x'])):
        for ot,pkt in pending:
            if ot+c.delay==t:
                if ot<c.warm and name.startswith('Legacy:'):
                    # Legacy per-source calibrators need their historical prediction packet.
                    _,pkt=model.predict(d['y'][ot,None,:],commit=False,t=ot)
                model.audit(ot,pkt,np.array([d['ref'][ot]]),np.array([d['audit'][ot]]))
                if d['audit'][ot]:
                    if t<=d['start']:learn_arrivals+=1
                    else:arrivals+=1
        pending=[a for a in pending if a[0]+c.delay>t]
        out,pkt=model.predict(d['y'][t,None,:],commit=True,t=t);pending.append((t,pkt))
        if t>=d['start']:
            errors.append(float(out[0]-d['x'][t]));pred.append(float(out[0]));ivs.append(pkt.get('intervals',np.full((1,2),np.nan))[0]);switch.append(t==d['start'] or np.any(d['pattern'][t]!=d['pattern'][t-1]))
    e=np.array(errors);iv=np.array(ivs);valid=np.isfinite(iv).all(axis=1);truth=d['x'][d['start']:];r=dict(case=case,seed=seed,method=name,params=params,mae=float(abs(e).mean()),rmse=float(np.sqrt(np.mean(e*e))),worst32=float(np.convolve(abs(e),np.ones(32)/32,'valid').max()),first32=float(abs(e[:32]).mean()),switch_mae=float(abs(e)[switch].mean()),cum_abs=float(abs(e).sum()),interval_valid=float(valid.mean()),coverage=float(np.mean(valid&(truth>=iv[:,0])&(truth<=iv[:,1]))) if valid.any() else 0.,width=float(np.mean((iv[:,1]-iv[:,0])[valid])) if valid.any() else None,reference_supply_learn=learn_arrivals,reference_supply_test=arrivals,N=N,T=d['T'],meta=d['meta'],runtime=time.perf_counter()-start_clock)
    if hasattr(model,'modes'):r['dictionary_size']=int(np.isfinite(model.modes).sum())
    if trace:return r,dict(pred=np.array(pred),truth=truth,reports=d['y'][d['start']:],error=e,interval=iv)
    return r

def configs():
    return [('ModeSet',dict(threshold=4.,coverage=.875,width=2.)),('ModeMAP',dict(threshold=4.,cap=16.)),('SingleState',dict(threshold=4.,coverage=.875,width=2.)),('JointTemplate',dict(threshold=4.,coverage=.875,width=2.)),('WarmJoint',dict(forget=.97)),('StableJoint',dict(forget=.9,ridge=.1)),('ContrastKNN',dict(neighbors=4,memory=64)),('AuditTV',dict(window=32,lam=.05,max_iter=600)),('Legacy:GainRepair',dict(rate=.2)),('Legacy:CalCRH_RLS',{}),('Legacy:CalRDPP_RLS',{}),('Legacy:TDSC_CRH_core',{}),('CPDZ-A',{}),('VRPM-A',{}),('MDM-core',{}),('DynaTD',dict(gamma=.98,smooth=0.)),('BoxMode',dict(factor=1.,fraction=.125))]

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--phase',choices=['smoke','main','sweep'],required=True);a=ap.parse_args();cfg=configs()
    core=[dict(ds='syn',scene=s,p=p) for s,p in [('seen',0.),('unseen',0.),('unseen',.05),('unseen',.25),('sync',0.),('clean',.25)]]+[dict(ds='syn',scene='unseen',p=.25,**kw) for kw in [dict(jitter=.1),dict(drift=.12)]]
    core += [dict(ds=d,scene=s,p=p) for d in ['air_hold1','air_hold2','air_hold3'] for s,p in [('unseen',0.),('unseen',.25),('clean',.25)]]
    if a.phase=='smoke':cases=[core[1],core[8]];seeds=[71090]
    elif a.phase=='main':cases=core;seeds=list(range(71100,71108))
    else:
        cfg=[q for q in cfg if q[0] in ['ModeSet','ModeMAP','JointTemplate','WarmJoint','StableJoint','ContrastKNN','AuditTV']]
        cases=[dict(ds='syn',scene='unseen',p=p) for p in [0.,.01,.05,.1,.25,.5]]
        cases += [dict(ds='extended',N=16,K=2,p=0.,learn_p=p) for p in [.05,.1,.25,.5]]
        cases += [dict(ds='extended',N=n,K=2,p=0.) for n in [8,16,32,64]]+[dict(ds='extended',N=16,K=k,p=0.) for k in [3,5]]
        seeds=list(range(72100,72106))
    jobs=[(c,s,m,p) for c in cases for s in seeds for m,p in cfg];out=BASE/a.phase;out.mkdir(exist_ok=True)
    deps=[Path(__file__),WORK/'v11/data.py',WORK/'v11/core.py',WORK/'v11/study.py',WORK/'v11/stable.py',WORK/'v9/candidates.py',WORK/'v9/temporal_baselines.py',WORK/'v10/models.py',WORK/'v10/local_model.py',WORK/'v8/methods.py',WORK/'v8/gates.py',WORK/'v6/baselines/mdm_cpdz.py',WORK/'v6/baselines/prtd_vrpmtd.py']
    hashes={str(p.relative_to(WORK)):hashlib.sha256(p.read_bytes()).hexdigest() for p in deps};(out/'frozen.json').write_text(json.dumps(dict(jobs=jobs,count=len(jobs),hashes=hashes,python=platform.python_version(),numpy=np.__version__),indent=2));rows=[]
    with ProcessPoolExecutor(max_workers=3) as pool:
        for f in as_completed([pool.submit(run,j) for j in jobs]):
            rows.append(f.result())
            if len(rows)%40==0:print(a.phase,len(rows),'/',len(jobs),flush=True);(out/'runs.json').write_text(json.dumps(rows,allow_nan=False))
    (out/'runs.json').write_text(json.dumps(rows,allow_nan=False))
    for n,h in hashes.items():assert hashlib.sha256((WORK/n).read_bytes()).hexdigest()==h
    print('DONE',a.phase,len(rows),flush=True)
if __name__=='__main__':main()
