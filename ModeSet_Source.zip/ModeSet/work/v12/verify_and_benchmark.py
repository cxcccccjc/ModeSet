from pathlib import Path
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1');os.environ.setdefault('OMP_NUM_THREADS','1')
import json,hashlib,pickle,copy,time,platform,subprocess
import numpy as np
import experiment as ex
BASE=Path(__file__).resolve().parent
def prepare(d,name,p):
    c=ex.SimpleNamespace(N=d['N'],J=1,G=d['N'],warm=d['warm'],T=d['T'],delay=d['delay'],reference_error=d['reference_error']);ids=[t for t in range(c.warm) if d['audit'][t] and t+c.delay<=c.warm]
    m=ex.construct(name,d['y'][ids]-d['ref'][ids,None],c,p,73100);m.initialize_history(d['y'][:c.warm,None,:],d['audit'][:,None],d['ref'][:,None],c.warm,c.delay);pending=[(t,dict(y=d['y'][t,None,:].copy())) for t in range(c.warm) if t+c.delay>c.warm]
    for t in range(c.warm,d['start']):
        for ot,pp in pending:
            if ot+c.delay==t:m.audit(ot,pp,np.array([d['ref'][ot]]),np.array([d['audit'][ot]]))
        pending=[a for a in pending if a[0]+c.delay>t];_,pp=m.predict(d['y'][t,None,:],commit=True,t=t);pending.append((t,pp))
    return m
def main():
    hashes=0;records=0;rr=[]
    for phase in ['main','sweep']:
        f=json.loads((BASE/phase/'frozen.json').read_text());rows=json.loads((BASE/phase/'runs.json').read_text());assert len(rows)==f['count'];records+=len(rows)
        keys=[json.dumps([r[k] for k in ['case','seed','method','params']],sort_keys=True) for r in rows];assert len(keys)==len(set(keys))
        for n,h in f['hashes'].items():assert hashlib.sha256((BASE.parent/n).read_bytes()).hexdigest()==h;hashes+=1
        rr+=rows
    for r in rr:
        if r['case'].get('scene')=='unseen' and not any(k in r['case'] for k in ['jitter','drift']):assert r['meta']['joint_overlap']==0
    # Every method is replayed, using one synthetic and one sensor case for the main model.
    replay=[]
    for name,p in ex.configs():
        old=next(r for r in rr if r['method']==name and r['case']==dict(ds='syn',scene='unseen',p=0.) and r['seed']==71100);new=ex.run((old['case'],old['seed'],name,p))
        assert abs(new['mae']-old['mae'])<1e-12;replay.append(name)
    tests=[];orig=ex.data;case=dict(ds='syn',scene='unseen',p=.25);d=orig(case,73100);cut=d['start']+50
    for name,p in [a for a in ex.configs() if a[0] in ['ModeSet','ModeMAP','JointTemplate','SingleState','WarmJoint','StableJoint','ContrastKNN','AuditTV','CPDZ-A']]:
        ex.data=lambda c,s:copy.deepcopy(d);a,tr=ex.run((case,73100,name,p),True)
        bad=copy.deepcopy(d);bad['ref'][~d['audit']]+=5000;ex.data=lambda c,s:copy.deepcopy(bad);b,tb=ex.run((case,73100,name,p),True);assert np.array_equal(tr['pred'],tb['pred'])
        bad=copy.deepcopy(d);bad['ref'][cut:]+=5000;ex.data=lambda c,s:copy.deepcopy(bad);b,tb=ex.run((case,73100,name,p),True);h=cut+d['delay']-d['start'];assert np.array_equal(tr['pred'][:h],tb['pred'][:h])
        ex.data=orig;m=prepare(d,name,p);before=pickle.dumps(m.__dict__);m.predict(d['y'][d['start'],None,:],False,d['start']);assert before==pickle.dumps(m.__dict__);tests.append(dict(method=name,unselected_labels=True,future_reference_isolation=True,pure_query=True))
    ex.data=orig
    # Full time-varying common shifts leave residual learning unchanged.
    p=dict(ex.configs())['ModeSet'];base,tr=ex.run((case,73101,'ModeSet',p),True);dd=orig(case,73101);shift=3*np.sin(np.arange(len(dd['x']))/7);shift[dd['start']+40:]+=50;dd['y']+=shift[:,None];dd['ref']+=shift;dd['x']+=shift;ex.data=lambda c,s:copy.deepcopy(dd);_,tt=ex.run((case,73101,'ModeSet',p),True);ex.data=orig;equiv=float(np.max(abs(tt['pred']-tr['pred']-shift[dd['start']:])));assert equiv<1e-10
    coverage=[]
    for r in rr:
        if r['method']=='ModeSet':coverage.append(dict(case=r['case'],seed=r['seed'],all_local_states_audited=r['meta'].get('each_active_source_audited',r['meta'].get('states_covered')==r['meta'].get('states_required'))))
    (BASE/'checks.json').write_text(json.dumps(dict(records=records,hash_checks=hashes,replayed_methods=replay,causal_checks=tests,common_shift_max_difference=equiv,coverage=coverage,pass_all=True),indent=2))
    print('CHECKS PASS',records,len(replay),flush=True)
    # Single-process steady read-only inference, setup and label updates excluded.
    bench=[]
    for N in [8,16,32,64]:
        d=ex.extended(73102,N=N,K=2,p=0.)
        for name,p in [a for a in ex.configs() if a[0] in ['ModeSet','ModeMAP','JointTemplate','WarmJoint','StableJoint','ContrastKNN','AuditTV']]:
            m=prepare(d,name,p);times=[]
            for k in range(55):
                y=d['y'][d['start']+k,None,:];start=time.perf_counter_ns();m.predict(y,False,d['start']+k);elapsed=(time.perf_counter_ns()-start)/1e6
                if k>=5:times.append(elapsed)
            bench.append(dict(N=N,method=name,samples=len(times),median_ms=float(np.median(times)),p95_ms=float(np.quantile(times,.95)),mean_ms=float(np.mean(times))));print('benchmark',N,name,flush=True)
    import winreg
    with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,r'HARDWARE\DESCRIPTION\System\CentralProcessor\0') as k:cpu=winreg.QueryValueEx(k,'ProcessorNameString')[0]
    (BASE/'benchmark.json').write_text(json.dumps(dict(cpu=cpu,platform=platform.platform(),python=platform.python_version(),numpy=np.__version__,blas_threads=1,protocol='sequential process; 5 warmup + 50 distinct read-only predictions; excludes setup and reference updates; no energy/online-throughput claim',rows=bench),indent=2));print('BENCH DONE',flush=True)
if __name__=='__main__':main()
