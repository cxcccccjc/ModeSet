"""State-query adversary constrained to held-out joint patterns, no current honest reports or labels."""
from pathlib import Path
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1');os.environ.setdefault('OMP_NUM_THREADS','1')
import importlib.util,json,hashlib,pickle,time
from concurrent.futures import ProcessPoolExecutor,as_completed
import numpy as np
BASE=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('v12_adaptive_ex',BASE/'experiment.py');st=importlib.util.module_from_spec(sp);sp.loader.exec_module(st)

def run(job):
    case,seed,name,params=job;d=st.data(case,seed);N=d['N'];c=st.SimpleNamespace(N=N,J=1,G=N,warm=d['warm'],T=d['T'],delay=d['delay'],reference_error=d['reference_error']);ids=[t for t in range(c.warm) if d['audit'][t] and t+c.delay<=c.warm];cal=d['y'][ids]-d['ref'][ids,None]
    model=st.construct(name,cal,c,params,seed);model.initialize_history(d['y'][:c.warm,None,:],d['audit'][:,None],d['ref'][:,None],c.warm,c.delay)
    pending=[(t,dict(y=d['y'][t,None,:].copy())) for t in range(c.warm) if t+c.delay>c.warm];errors=[];choices=[];bad=d['bad'];amplitudes=np.array(d['meta']['amplitudes']);pool=d['meta']['heldout_patterns'][:8];start=time.perf_counter();query_checks=0
    for t in range(c.warm,len(d['x'])):
        for ot,pkt in pending:
            if ot+c.delay==t:model.audit(ot,pkt,np.array([d['ref'][ot]]),np.array([d['audit'][ot]]))
        pending=[x for x in pending if x[0]+c.delay>t];yy=d['y'][t].copy()
        if t>=d['start']:
            owned=d['clean'][t,bad];proxy_center=float(owned.mean());proxy=np.full(N,proxy_center);proxy[bad]=owned;best=-np.inf;chosen=None
            before=pickle.dumps(model.__dict__) if (t-d['start'])%40==0 else None
            for pidx,pattern in enumerate(pool):
                payload=np.zeros(len(bad));payload[pattern]=amplitudes[pattern];fake=proxy.copy();fake[bad]+=payload;estimate=model.predict(fake[None,:],commit=False,t=t)[0][0];score=abs(estimate-proxy_center)
                if score>best:best=score;chosen=(pidx,payload)
            if before is not None:assert pickle.dumps(model.__dict__)==before;query_checks+=1
            yy=d['clean'][t].copy();yy[bad]+=chosen[1];choices.append(chosen[0])
        out,pkt=model.predict(yy[None,:],commit=True,t=t);pending.append((t,pkt))
        if t>=d['start']:errors.append(float(out[0]-d['x'][t]))
    e=np.array(errors)
    return dict(case=case,seed=seed,method=name,params=params,mae=float(abs(e).mean()),rmse=float(np.sqrt(np.mean(e*e))),cum_abs=float(abs(e).sum()),first32=float(abs(e[:32]).mean()),worst32=float(np.convolve(abs(e),np.ones(32)/32,'valid').max()),query_purity_checks=query_checks,unique_selected_patterns=len(set(choices)),candidate_patterns=len(pool),label_note='Same adversary policy but method-dependent payload; not identical attacked trajectories.',meta=d['meta'],runtime=time.perf_counter()-start)
def main():
    cfg=[a for a in st.configs() if a[0] in ['ModeSet','ModeMAP','JointTemplate','WarmJoint','StableJoint','ContrastKNN','AuditTV']]
    cases=[dict(ds='syn',scene='unseen',p=p) for p in [0.,.25]]+[dict(ds='air_hold2',scene='unseen',p=.25)]
    jobs=[(c,s,m,p) for c in cases for s in range(75100,75106) for m,p in cfg]
    out=BASE/'adaptive';out.mkdir(exist_ok=True)
    deps=json.loads((BASE/'main/frozen.json').read_text())['hashes'];deps['v12/adaptive.py']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    (out/'frozen.json').write_text(json.dumps(dict(jobs=jobs,count=len(jobs),hashes=deps,protocol='Eight held-out candidate patterns; proxy made from owned sensors only; current hidden audit coin and true value unavailable to attack selection; method-dependent attacks'),indent=2));rows=[]
    with ProcessPoolExecutor(max_workers=3) as pool:
        for f in as_completed([pool.submit(run,j) for j in jobs]):
            rows.append(f.result())
            if len(rows)%14==0:print('adaptive',len(rows),'/',len(jobs),flush=True)
    (out/'runs.json').write_text(json.dumps(rows,allow_nan=False))
    for n,h in deps.items():assert hashlib.sha256((BASE.parent/n).read_bytes()).hexdigest()==h
    print('DONE',len(rows),flush=True)
if __name__=='__main__':main()
