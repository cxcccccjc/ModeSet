"""002 revision: fixed-protocol MDM-core extension and retained-cohort selection."""
from pathlib import Path
import json,hashlib,importlib.util,os
from concurrent.futures import ProcessPoolExecutor,as_completed
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
os.environ.setdefault('OMP_NUM_THREADS','1')
BASE=Path(__file__).resolve().parent
OLD=BASE.parent/'v12'
def load_driver(name):
    spec=importlib.util.spec_from_file_location('revision_'+name,OLD/(name+'.py'))
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);return mod
DRIVERS={}
def run(item):
    phase,job=item
    driver='experiment' if phase in ['main','sweep'] else phase
    if driver not in DRIVERS:DRIVERS[driver]=load_driver(driver)
    return phase,DRIVERS[driver].run(job)
def key(job):return json.dumps(job,sort_keys=True)
def main():
    todo=[];cohorts={};original_hashes={};jobs_by={}
    for phase in ['main','sweep','conditions','adaptive']:
        old=json.loads((OLD/phase/'runs.json').read_text());f=json.loads((OLD/phase/'frozen.json').read_text())
        kept=[r for r in old if r['method']!='ModeMAP'];jobs=[[r[k] for k in ['case','seed','method','params']] for r in kept]
        existing={key(j) for j in jobs}
        for r in old:
            if r['method']=='ModeMAP':
                j=[r['case'],r['seed'],'MDM-core',{}]
                if key(j) not in existing:todo.append((phase,j));jobs.append(j);existing.add(key(j))
        cohorts[phase]=kept;jobs_by[phase]=jobs;original_hashes[phase]=f['hashes']
    assert len(todo)==240
    dep_hash=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    (BASE/'extension_frozen.json').write_text(json.dumps({'jobs':todo,'count':len(todo),'driver_sha256':dep_hash,'protocol':'Same scenarios, seeds, delays and reference budgets; unchanged MDM-core implementation; no parameter search.'},indent=2),encoding='utf-8')
    added=[]
    with ProcessPoolExecutor(max_workers=3) as pool:
        futures=[pool.submit(run,j) for j in todo]
        for f in as_completed(futures):
            phase,row=f.result();cohorts[phase].append(row);added.append({'phase':phase,'record':row})
            if len(added)%20==0:print('MDM-core extension',len(added),'/',len(todo),flush=True)
    (BASE/'extension_runs.json').write_text(json.dumps(added,allow_nan=False),encoding='utf-8')
    for phase,rows in cohorts.items():
        p=BASE/phase;p.mkdir(exist_ok=True)
        rows.sort(key=lambda r:key([r[k] for k in ['case','seed','method','params']]))
        hashes=dict(original_hashes[phase]);hashes['v13/update_cohorts.py']=dep_hash
        for n,h in hashes.items():assert hashlib.sha256((BASE.parent/n).read_bytes()).hexdigest()==h,n
        assert {key([r[k] for k in ['case','seed','method','params']]) for r in rows}=={key(j) for j in jobs_by[phase]}
        (p/'runs.json').write_text(json.dumps(rows,allow_nan=False),encoding='utf-8')
        (p/'frozen.json').write_text(json.dumps({'jobs':jobs_by[phase],'count':len(rows),'hashes':hashes,'origin':'Retained original records plus the fixed MDM-core extension; ModeMAP excluded from 002 comparisons.'},indent=2),encoding='utf-8')
    report={'retained_records':3742,'new_mdm_records':240,'formal_records':sum(map(len,cohorts.values())),'phases':{p:len(r) for p,r in cohorts.items()},'model_changed':False,'hyperparameters_changed':False}
    assert report['formal_records']==3982
    (BASE/'cohort_provenance.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(report,flush=True)
if __name__=='__main__':main()
