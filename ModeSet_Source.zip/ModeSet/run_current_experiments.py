"""Run selected current-paper jobs into a new directory, preserving frozen data.

Default: one ModeSet synthetic job. Use --all explicitly for all current jobs.
"""
from pathlib import Path
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
os.environ.setdefault('OMP_NUM_THREADS','1')
import argparse
import hashlib
import json
from concurrent.futures import ProcessPoolExecutor,as_completed
from verify_and_replay import ROOT,PHASES,load_driver,job

DRIVERS={}

def run(item):
    phase,record=item
    if phase not in DRIVERS:DRIVERS[phase]=load_driver(phase)
    return phase,DRIVERS[phase].run(job(record))

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--all',action='store_true',help='Run every job matching the filters.')
    parser.add_argument('--phase',choices=PHASES)
    parser.add_argument('--method')
    parser.add_argument('--dataset')
    parser.add_argument('--limit',type=int,default=1)
    parser.add_argument('--workers',type=int,default=1)
    parser.add_argument('--output',required=True,help='New output directory; existing directories are refused.')
    args=parser.parse_args()
    if args.limit<1 or args.workers<1:parser.error('limit and workers must be positive')
    selected=[]
    for phase in PHASES:
        if args.phase and args.phase!=phase:continue
        rows=json.loads((ROOT/'current_data'/(phase+'.json')).read_text(encoding='utf-8'))
        for record in rows:
            if args.method and record['method']!=args.method:continue
            if args.dataset and record['case'].get('ds')!=args.dataset:continue
            selected.append((phase,record))
    if not args.all:
        # Safe small default; explicit filters can select another method or domain.
        if not args.method:selected=[a for a in selected if a[1]['method']=='ModeSet']
        if not args.dataset:selected=[a for a in selected if a[1]['case'].get('ds')=='syn']
        selected=selected[:args.limit]
    if not selected:parser.error('No current-paper jobs matched the filters')
    out=Path(args.output)
    if not out.is_absolute():out=ROOT/out
    if out.exists():parser.error('Output directory already exists; select a new name')
    out.mkdir(parents=True)
    hashes={p.relative_to(ROOT/'work').as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
            for p in (ROOT/'work').rglob('*.py')}
    for phase in PHASES:
        jobs=[job(r) for ph,r in selected if ph==phase]
        if jobs:
            folder=out/phase;folder.mkdir()
            (folder/'frozen.json').write_text(json.dumps(dict(count=len(jobs),jobs=jobs,hashes=hashes,
                source='current paper selected jobs; this is a new run, not the archived evidence'),indent=2),encoding='utf-8')
    results={p:[] for p in PHASES}
    if args.workers==1:
        for item in selected:
            phase,row=run(item);results[phase].append(row)
            print('Finished',sum(map(len,results.values())),'/',len(selected),flush=True)
    else:
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            for future in as_completed([pool.submit(run,item) for item in selected]):
                phase,row=future.result();results[phase].append(row)
                count=sum(map(len,results.values()))
                if count%20==0 or count==len(selected):print('Finished',count,'/',len(selected),flush=True)
    for phase,rows in results.items():
        if rows:
            rows.sort(key=lambda r:json.dumps(job(r),sort_keys=True))
            (out/phase/'runs.json').write_text(json.dumps(rows,allow_nan=False),encoding='utf-8')
    print('New results:',out)

if __name__=='__main__':main()
