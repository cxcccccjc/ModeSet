"""Portable verification of the current selection and representative frozen runs.

All paths are relative to this file. Original code, data, and run records are read
only. The only generated artifact is the requested verification report.
"""
from pathlib import Path
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS', '1')
os.environ.setdefault('OMP_NUM_THREADS', '1')
import argparse
import csv
import hashlib
import importlib.util
import json
import platform
import sys
import time
import numpy as np

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
WORK = ROOT / 'work'
PHASES = ['main', 'sweep', 'conditions', 'adaptive']

def read(path):
    return json.loads(path.read_text(encoding='utf-8'))

def job(row):
    return [row[k] for k in ['case', 'seed', 'method', 'params']]

def key(value):
    return json.dumps(value, sort_keys=True)

def load_driver(phase):
    filename = 'experiment.py' if phase in ['main', 'sweep'] else phase+'.py'
    spec = importlib.util.spec_from_file_location('archive_replay_'+phase, WORK/'v12'/filename)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group()
    group.add_argument('--quick', action='store_true', help='Replay eight representative records (default).')
    group.add_argument('--check-only', action='store_true', help='Check hashes/selection/summary without numerical replay.')
    parser.add_argument('--output', default='reports/current_replay.json')
    args = parser.parse_args()
    checks = []
    current = {}
    for version in ['v12', 'v13']:
        for phase in PHASES:
            frozen = read(WORK/version/phase/'frozen.json')
            rows = read(WORK/version/phase/'runs.json')
            actual = {key(job(r)) for r in rows}
            assert len(rows) == frozen['count'] == len(actual), (version, phase)
            assert actual == {key(j) for j in frozen['jobs']}, (version, phase)
            for relative, expected in frozen['hashes'].items():
                # Original manifests can contain Windows separators.
                source = WORK / relative.replace('\\', '/')
                assert hashlib.sha256(source.read_bytes()).hexdigest() == expected, source
            checks.append(dict(version=version, phase=phase, records=len(rows),
                               checked_sources=len(frozen['hashes']), passed=True))
            if version == 'v13':
                selected = read(ROOT/'current_data'/(phase+'.json'))
                assert selected == [r for r in rows if r['method'] != 'SingleState']
                assert not any(r['method'] in ['SingleState','ModeMAP'] for r in selected)
                current[phase] = selected
    assert sum(map(len,current.values())) == 3846
    # The supplied CSV must agree with its per-seed records, including all metric values.
    lookup = {}
    for phase, rows in current.items():
        for row in rows:
            lookup.setdefault((phase,key(row['case']),row['method']),[]).append(row)
    summary_count = 0
    with (ROOT/'current_data/summary.csv').open(encoding='utf-8-sig', newline='') as f:
        for row in csv.DictReader(f):
            group_rows = lookup[(row['phase'],key(json.loads(row['case'])),row['method'])]
            assert int(row['n']) == len(group_rows)
            for column, value in row.items():
                if value and column.endswith(('_mean','_sd')):
                    metric, statistic = column.rsplit('_',1)
                    values = [r[metric] for r in group_rows if r.get(metric) is not None]
                    expected = np.mean(values) if statistic == 'mean' else np.std(values,ddof=1)
                    assert abs(float(value)-expected)<1e-10,(row['method'],column)
            summary_count += 1
    assert summary_count == len(lookup)
    print('PASS frozen cohorts, source integrity, current selection, and summary', flush=True)
    replay = []
    geometry_count = 0
    if not args.check_only:
        # Three independent drivers, real inputs, and two relevant numerical baselines.
        targets = [
            ('main','syn','ModeSet',0.),
            ('main','syn','MDM-core',0.),
            ('main','syn','WarmJoint',0.),
            ('main','air_hold2','ModeSet',0.),
            ('conditions','syn','ModeSet',.25),
            ('conditions','gas3','ModeSet',0.),
            ('conditions','gas7','ModeSet',0.),
            ('adaptive','syn','ModeSet',0.),
        ]
        drivers = {}
        for phase, dataset, method, probability in targets:
            if phase not in drivers:
                drivers[phase] = load_driver(phase)
            eligible = [r for r in current[phase] if r['method']==method and
                        r['case'].get('ds')==dataset and r['case'].get('p')==probability]
            old = sorted(eligible,key=lambda r:(r['seed'],key(r['case'])))[0]
            start = time.perf_counter()
            new = drivers[phase].run(job(old))
            metrics = ['mae','rmse','worst32','first32','cum_abs']
            difference = max(abs(old[k]-new[k]) for k in metrics)
            assert difference < 1e-9,(phase,method,dataset,difference)
            replay.append(dict(phase=phase,method=method,case=old['case'],seed=old['seed'],
                               metrics=metrics,max_absolute_difference=difference,
                               elapsed_seconds=time.perf_counter()-start))
            print('PASS',phase,dataset,method,'max difference',difference,flush=True)
        # A small deterministic geometry check, independent of performance records.
        ex = drivers['main']
        rng = np.random.default_rng(76100)
        for _ in range(100):
            n=7; k=3; allowed=1
            centers=np.sort(rng.uniform(-2,2,(n,k)),axis=1)
            radii=rng.uniform(.01,.2,n)
            diameter=ex.st.confusion_radius([[[float(v),float(v)] for v in row] for row in centers],radii,allowed)
            truth=rng.uniform(-3,3); states=rng.integers(0,k,n)
            reports=truth+centers[np.arange(n),states]+rng.uniform(-1,1,n)*radii
            reports[rng.integers(n)]+=rng.uniform(-4,4)
            feasible=ex.supported_intervals(reports,centers,radii,n-allowed)
            assert feasible is not None
            assert feasible[0]-1e-10<=truth<=feasible[1]+1e-10
            assert feasible[1]-feasible[0]<=diameter+1e-10
            geometry_count+=1
        # Prove that the imported implementation closure comes from this extraction.
        for name in ['candidates','methods','gates','models','core','data','temporal_baselines']:
            source=Path(sys.modules[name].__file__).resolve()
            assert source.is_relative_to(ROOT.resolve()),(name,source)
    report = dict(all_passed=True,python=platform.python_version(),numpy=np.__version__,
                  archive_root=str(ROOT),selection_records=sum(map(len,current.values())),
                  selection_counts={p:len(v) for p,v in current.items()},
                  frozen_cohorts=checks,current_summary_rows=summary_count,
                  representative_replays=replay,static_geometry_checks=geometry_count,
                  writes_original_records=False)
    output=Path(args.output)
    if not output.is_absolute(): output=ROOT/output
    assert output.resolve().is_relative_to((ROOT/'reports').resolve()), 'Use an output path under reports/.'
    output.parent.mkdir(parents=True,exist_ok=True)
    output.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print('ALL PASS. Report:',output,flush=True)

if __name__ == '__main__':
    main()
