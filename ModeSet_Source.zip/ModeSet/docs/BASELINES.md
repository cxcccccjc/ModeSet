# Baseline and adaptation scope

Method identifiers are preserved from the frozen records. Several are study controls or adaptations rather than names of independently published complete systems.

| Identifier | Implementation scope |
| --- | --- |
| `ModeSet` | Proposed source-specific recurrent-state learner and interval-composition decoder. |
| `JointTemplate` | Structural control that stores observed joint state vectors and restricts decoding and fallback to those templates. |
| `WarmJoint` | Joint recursive least-squares calibration initialized from the shared warm-up references. |
| `StableJoint` | Joint ridge calibration with persistent normal-equation updates. |
| `ContrastKNN` | Residual-vector neighbor calibration control. |
| `AuditTV` | Study adaptation inspired by sparsity-based robust smoothing, with returned references and a temporal bias penalty. It is not a full reproduction of Farahmand et al., IEEE TSP 2011. |
| `BoxMode` | Interval/box variant implemented by the study. |
| `DynaTD` | Temporal truth-discovery numerical implementation following Li et al., KDD 2015, Eqs. (11)–(12) and Algorithm 1, as recorded in the source. |
| `MDM-core` | Numerical truth-finding core of the multi-round poisoning defense, with the documented scalar-distance interpretation and fixed reset schedule. No communication or privacy protocol is reproduced. |
| `CPDZ-A` | CPDZ credibility-related numerical adaptation to shared returned references. Recruitment, cryptographic mechanisms, and the unspecified printed TAST component are outside this implementation. |
| `VRPM-A` | Scalar numerical VRPMTD state update with the declared absolute-distance choice. Cryptography, quantization, and packet verification are outside this implementation. |
| `Legacy:GainRepair` | Study calibration control based on source-level bias estimates and learned correction gains. |
| `Legacy:CalCRH_RLS` | Source-wise recursive least-squares calibration followed by the CRH numerical aggregator. |
| `Legacy:CalRDPP_RLS` | Source-wise recursive least-squares calibration followed by the study's reputation-weighted numerical aggregation adaptation. |
| `Legacy:TDSC_CRH_core` | CRH-style numerical aggregation core used as the literature-related comparator; it is not a full security/privacy-system replication. |

The exact parameters for every experiment are in each result record's `params` field and in the corresponding frozen task manifest. Parameters chosen for unspecified source-paper quantities are implementation assumptions rather than recovered paper defaults. Source docstrings state formula mappings, floors, stopping limits, and adaptation boundaries where relevant.

`work/v6/baselines/longterm.py` and additional historical constructors remain because the source dependency structure is preserved. Their presence does not mean they are among the 15 current-paper comparisons. Internal reading-note files mentioned by some original source comments are not part of this public repository; this document and the preserved implementation comments describe the public implementation scope.

Reference schedules and reported input streams follow the same recorded experimental condition. In the adaptive tests, attack payloads depend on the queried method, as reflected in the paired-statistics interpretation. The archived records include both favorable and unfavorable evaluated conditions.
