# Public data provenance

## Air Quality

- UCI dataset: [Air Quality](https://archive.ics.uci.edu/dataset/360/air+quality)
- Dataset DOI: [10.24432/C59K5F](https://doi.org/10.24432/C59K5F)
- Included file: `work/data/uci_air_quality/AirQualityUCI.csv`
- Original archive and download metadata: `work/data/download_manifest.json`
- Preserved UCI metadata: `work/data/uci_air_quality_metadata.json`
- Introductory paper: S. De Vito, E. Massera, M. Piga, L. Martinotto, and G. Di Francia, "On field calibration of an electronic nose for benzene estimation in an urban pollution monitoring scenario," *Sensors and Actuators B: Chemical*, 2008, DOI [10.1016/j.snb.2007.09.060](https://doi.org/10.1016/j.snb.2007.09.060).

The experiment extracts the CO reference and the five sensor channels; its preprocessing and held-out windows are defined in `work/v11/data.py`. The preserved upstream description specifies research use, excludes commercial use, and requests citation of the source paper. Consult the upstream dataset for its current terms before reuse.

## Gas Sensor Array Drift Dataset at Different Concentrations

- UCI dataset: [Gas Sensor Array Drift Dataset at Different Concentrations](https://archive.ics.uci.edu/dataset/270/gas+sensor+array+drift+dataset+at+different+concentrations)
- Dataset DOI: [10.24432/C5MK6M](https://doi.org/10.24432/C5MK6M)
- Included subset: `work/v7/gas/batch1.dat`, `batch2.dat`, `batch3.dat`, and `batch7.dat`
- Preserved source metadata: `work/v7/sources/gas_metadata.json`

The included files are the complete subset used by the experiments, not the full ten-batch dataset. The protocol uses fitting and warm-up batches separately from the two transfer batches. Preprocessing, batch selection, and sequence construction are defined in `work/v12/conditions.py`. Retain the upstream dataset attribution and follow its terms and publication-citation requirements.

## Generated data and evaluation scope

Synthetic data, poisoning injections, and reference schedules are generated using the configurations and random seeds in the frozen task manifests. Real sensor measurements are used as report streams, with attacks injected by the evaluation code. Gas-data row order defines the experimental sequence.

Raw result records and retained sensor inputs are preserved without numerical modification. Checksums for historical estimator dependencies are stored in the frozen manifests; the portable verifier validates them before replay. No human-identity labels, privately collected participant data, or credentials are required to run the experiments.
