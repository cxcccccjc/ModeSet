"""Export the paper's method selection without changing historical records."""
from pathlib import Path
import argparse
import csv
import json
from collections import defaultdict
import numpy as np

ROOT=Path(__file__).resolve().parent
PHASES=['main','sweep','conditions','adaptive']
METRICS=['mae','rmse','worst32','first32','cum_abs','coverage','interval_valid','width',
         'reference_supply_learn','reference_supply_test']

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source',default='work/v13',help='Source containing the four phase folders.')
    parser.add_argument('--output',default='derived/current_selection',help='Must be a new directory.')
    args=parser.parse_args()
    source=Path(args.source);out=Path(args.output)
    if not source.is_absolute():source=ROOT/source
    if not out.is_absolute():out=ROOT/out
    if out.exists():raise SystemExit('Choose a new output directory; existing evidence will not be overwritten.')
    out.mkdir(parents=True)
    summary=[];counts={};paired=[]
    for phase in PHASES:
        rows=json.loads((source/phase/'runs.json').read_text(encoding='utf-8'))
        rows=[r for r in rows if r['method'] not in {'SingleState','ModeMAP'}]
        counts[phase]=len(rows)
        (out/(phase+'.json')).write_text(json.dumps(rows,allow_nan=False),encoding='utf-8')
        groups=defaultdict(list)
        for r in rows:groups[(json.dumps(r['case'],sort_keys=True),r['method'])].append(r)
        for (case,method),rr in sorted(groups.items()):
            result=dict(phase=phase,case=case,method=method,n=len(rr))
            for metric in METRICS:
                values=[r[metric] for r in rr if r.get(metric) is not None]
                if values:
                    result[metric+'_mean']=float(np.mean(values))
                    result[metric+'_sd']=float(np.std(values,ddof=1))
            summary.append(result)
            ours=groups.get((case,'ModeSet'))
            if method!='ModeSet' and ours:
                by_seed={r['seed']:r for r in ours}
                difference=np.array([r['mae']-by_seed[r['seed']]['mae'] for r in rr])
                n=len(difference)
                critical={8:2.364624,6:2.570582}.get(n)
                if critical is not None:
                    half=critical*difference.std(ddof=1)/np.sqrt(n)
                    paired.append(dict(phase=phase,case=json.loads(case),comparator=method,n=n,
                        mean_difference_baseline_minus_modeset=float(difference.mean()),
                        lower=float(difference.mean()-half),upper=float(difference.mean()+half),
                        interpretation='descriptive paired t interval, no multiplicity adjustment; adaptive policy has method-dependent payloads' if phase=='adaptive' else 'descriptive paired t interval, no multiplicity adjustment'))
    columns=['phase','case','method','n']+[k+s for k in METRICS for s in ['_mean','_sd']]
    with (out/'summary.csv').open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=columns);writer.writeheader();writer.writerows(summary)
    (out/'paired_intervals.json').write_text(json.dumps(paired,indent=2),encoding='utf-8')
    (out/'selection.json').write_text(json.dumps(dict(source=str(source),counts=counts,
        excluded_methods=['SingleState','ModeMAP'],raw_records_modified=False),indent=2),encoding='utf-8')
    print('Exported',sum(counts.values()),'records to',out)

if __name__=='__main__':main()
