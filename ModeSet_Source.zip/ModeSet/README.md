# ModeSet

Reproducibility repository for **ModeSet: Compositional Truth Discovery Against Recurrent Coordinated Poisoning**.

Repository: https://github.com/cxcccccjc/ModeSet

ModeSet learns source-specific recurrent bias states from returned references and combines their compatible truth intervals at inference time. The experiments evaluate recurrent coordinated poisoning, unseen state combinations, environmental change, limited references, and sensor-domain transfer.

This repository contains the numerical implementations, fixed experiment configurations, required public sensor inputs, per-seed results, and scripts for verification and rerunning the paper's experiments. The relative `work/v*` directory structure preserves the original implementation dependencies; these are not separate packages to install.

## Quick start

Use Python 3.12. The archived numerical environment is Python 3.12.14 with NumPy 2.3.5. From the repository root:

```bash
python -m pip install -r requirements.txt
python verify_and_replay.py --quick
```

The quick check verifies frozen task configurations, unchanged implementation files, the current method selection, and all 556 summary rows. It then replays eight representative records covering synthetic data, air-quality data, two gas-sensor transfer batches, and adaptive attacks; the replay includes ModeSet, MDM-core, and WarmJoint. It also checks 100 deterministic set-geometry instances. Generated verification reports are written under `reports/`; archived evidence is not overwritten.

For consistency checks without numerical replay:

```bash
python verify_and_replay.py --check-only
```

Timing values depend on the machine and are not required to reproduce exactly. Numerical replay uses the tolerance specified in the script.

## Rebuild experimental figures

Figures 5--11 are regenerated directly from the released per-seed records and inference benchmark:

```bash
python -m pip install -r figures/requirements.txt
python figures/plot_experiment_panels.py
```

The default English output is written to `derived/figures/en/` as PDF, editable-text SVG, and PNG. The script also exports the plotted numerical summaries. Optional Chinese rendering and font setup are described in [FIGURES.md](docs/FIGURES.md).

## Reproduce the current experiments

A single trial, written to a new output directory:

```bash
python run_current_experiments.py --phase main --method ModeSet --dataset syn --limit 1 --output derived/trial_001
```

All current ModeSet tasks:

```bash
python run_current_experiments.py --all --method ModeSet --workers 3 --output derived/modeset_001
```

All 3,846 current-paper tasks, followed by summary export:

```bash
python run_current_experiments.py --all --workers 3 --output derived/full_001
python export_current_selection.py --source derived/full_001 --output derived/full_001_summary
```

These commands refuse an existing output directory. They preserve the published records and save new configurations, results, and implementation checks in the new directory. The full run is substantially longer than the representative replay. The default runner executes one trial; `--all` explicitly requests every task matching the filters.

To regenerate the current selection directly from the historical frozen records, without rerunning estimators:

```bash
python export_current_selection.py --output derived/selected_001
```

## Evidence and method identifiers

`current_data/` is the selection used by the current manuscript and supplement:

| Phase | Per-seed records | Methods | Conditions | Seeds per condition/method |
| --- | ---: | ---: | ---: | ---: |
| `main` | 2,040 | 15 | 17 | 8 |
| `sweep` | 672 | 7 | 16 | 6 |
| `conditions` | 1,008 | 8 | 21 | 6 |
| `adaptive` | 126 | 7 | 3 | 6 |
| Total | 3,846 | | | |

Each record includes `case`, `seed`, `method`, `params`, error metrics, and reference counts. `summary.csv` contains 556 condition/method summaries. `paired_intervals.json` retains the descriptive paired statistics; `cohorts.json` and `selection_provenance.json` describe the selection; `ablation_evidence.json` contains the values used in the compositional ablation figure.

The 15 current method identifiers are:

```text
ModeSet, JointTemplate, WarmJoint, StableJoint, ContrastKNN, AuditTV,
BoxMode, DynaTD, MDM-core, CPDZ-A, VRPM-A,
Legacy:GainRepair, Legacy:CalCRH_RLS, Legacy:CalRDPP_RLS,
Legacy:TDSC_CRH_core
```

The `Legacy:` prefix is an internal dispatch name. These names are not claims that all methods are independently published algorithms. JointTemplate is a structural control; WarmJoint, StableJoint, ContrastKNN, AuditTV, BoxMode, and GainRepair are calibration controls or study variants. Literature-related implementations reproduce the indicated **numerical cores or declared adaptations**, not complete privacy, cryptographic, recruitment, or network protocols. See [baseline scope](docs/BASELINES.md) and the source docstrings for the exact implementation boundary.

Historical cohorts remain under `work/v12/` (4,118 records) and `work/v13/` (3,982 records). The current selection removes `SingleState` from v13 without changing retained values. The v13 selection removes `ModeMAP` from v12 and adds 240 fixed-protocol MDM-core records. These overlapping cohorts must not be added together. Historical source definitions and results for removed methods are retained to make provenance verifiable; they are not current manuscript comparisons.

## Source map

| Path | Purpose |
| --- | --- |
| `work/v9/candidates.py` | ModeSet state learning, compatible intervals, and prediction |
| `work/v12/experiment.py` | Main and parameter-sweep drivers, current constructors, JointTemplate, baseline adapters |
| `work/v11/data.py` | Synthetic and air-quality preprocessing, attack states, and reference schedules |
| `work/v12/conditions.py` | Jitter, drift, new states, reference delay, and gas-sensor transfer |
| `work/v12/adaptive.py` | Query-limited adaptive coordinated attacks |
| `work/v11/core.py` | BoxMode and set geometry |
| `work/v11/stable.py` | StableJoint |
| `work/v10/models.py` | WarmJoint and ContrastKNN |
| `work/v9/temporal_baselines.py` | DynaTD and AuditTV |
| `work/v8/methods.py` | GainRepair, CRH-related cores, and calibrated adapters |
| `work/v6/baselines/` | Literature numerical cores and shared-reference adaptations |
| `work/v13/update_cohorts.py` | Fixed-protocol MDM-core extension and historical cohort assembly |
| `work/v12/theory_checks.py` | Conditional finite-state, exposure, and indistinguishability diagnostics |
| `work/v12/verify_and_benchmark.py` | Historical information-flow checks and CPU inference measurements |

The files needed by the above imports are included. The original estimators and frozen numerical records are preserved byte-for-byte.

## Data

Required real inputs are included, so numerical reproduction does not require a data download. Attribution, source links, and the exact included subset are documented in [DATA_SOURCES.md](docs/DATA_SOURCES.md).

- **UCI Air Quality**, DOI [10.24432/C59K5F](https://doi.org/10.24432/C59K5F): `work/data/uci_air_quality/AirQualityUCI.csv`; the experiment uses CO reference values and five sensor channels.
- **UCI Gas Sensor Array Drift Dataset at Different Concentrations**, DOI [10.24432/C5MK6M](https://doi.org/10.24432/C5MK6M): `work/v7/gas/batch1.dat`, `batch2.dat`, `batch3.dat`, and `batch7.dat`. These are the four batches used for fitting, warm-up, and transfer evaluation, not the entire ten-batch dataset.
- Synthetic streams, attack injections, and reference schedules are generated by the recorded configurations and seeds. Sensor experiments use measured reports with injected attacks; they are not observations of naturally occurring malicious participants.

Theoretical bounds use the assumptions stated in the supplement. Empirically fitted MAD radii are not assigned unconditional confidence guarantees by the repository checks.

## Historical diagnostics

The frozen historical drivers can be rerun in a **separate copy**, since they write to their own historical result directories:

```bash
python work/v12/experiment.py --phase main
python work/v12/experiment.py --phase sweep
python work/v12/conditions.py
python work/v12/adaptive.py
python work/v13/update_cohorts.py
```

For current-paper experiments, use `run_current_experiments.py` instead. Historical drivers include methods that were later removed from the current selection. Likewise, `python work/v12/theory_checks.py` and `python work/v12/verify_and_benchmark.py` regenerate historical diagnostic reports and should be run in a copy. The latter reads the Windows registry for the hardware model; the portable numerical entry points do not depend on that hardware-identification operation.

## Repository scope

This repository provides the experiment code and evidence. Manuscript PDFs, author photographs, cover letters, internal review notes, downloaded third-party papers, bundled interpreters, and typesetting engines are not part of the code release. Local outputs under `reports/` and `derived/` are ignored by Git. Third-party data remain subject to their upstream terms and citation requirements.
