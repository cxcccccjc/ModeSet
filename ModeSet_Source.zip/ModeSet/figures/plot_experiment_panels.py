"""Rebuild Figures 5--11 from the released, selected experiment records.

Run from any directory. Defaults resolve relative to the repository root.
No experiment or estimator is run. Dependencies: NumPy and Matplotlib.
English output (the default) needs no Chinese fonts. Optional Chinese output
retains the original Chinese manuscript's figure-language choices.
"""
from pathlib import Path
import argparse, copy, json, os
B=Path(__file__).resolve().parent
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--research',type=Path,default=B.parent,
                    help='Repository root containing current_data/ and work/.')
parser.add_argument('--output',type=Path,default=B.parent/'derived/figures')
parser.add_argument('--language',choices=['en','zh','both'],default='en')
parser.add_argument('--font-dir',type=Path,default=None,
                    help='Optional folder of locally licensed Chinese .ttf/.otf fonts.')
args=parser.parse_args()
os.environ.setdefault('MPLCONFIGDIR',str(args.output/'mplconfig'))
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from io import BytesIO
BASE=args.research/'work/v13'
R={p:json.loads((args.research/'current_data'/(p+'.json')).read_text(encoding='utf-8')) for p in ['main','sweep','conditions']}
METHODS=['ModeSet','MDM-core','JointTemplate','WarmJoint','StableJoint','ContrastKNN','AuditTV','BoxMode']
COLORS=['#0B5CAD','#7C3F99','#AF7921','#B64040','#0F766E','#505C68','#D06014','#3F8A66']
MARKERS=['o','s','^','D','v','P','x','*'];STYLES=['-','--','-.',':','--','-.',':','--']
P={m:(COLORS[i],MARKERS[i],STYLES[i]) for i,m in enumerate(METHODS)}
DATA=[]; LAYOUT=[]
FIG=args.output/('zh' if args.language=='zh' else 'en')
FIG.mkdir(parents=True,exist_ok=True)
ZH_FONT='Microsoft YaHei'

def style(zh=False):
    plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':[ZH_FONT if zh else 'Arial','DejaVu Sans'],'font.size':7.5,'axes.titlesize':8,'axes.labelsize':7.5,'xtick.labelsize':7.2,'ytick.labelsize':7.2,'legend.fontsize':7.2,'axes.linewidth':.65,'lines.linewidth':1.05,'lines.markersize':3.2,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'svg.fonttype':'none'})

def save(f,name):
    # Retain the original tight crop exactly. Use the former title space to
    # translate all axes upwards, then place original titles below the axes.
    # Capture the vector backend's original crop rather than an Agg estimate;
    # the two backends differ slightly in font metrics.
    tight_method=f.get_tightbbox
    captured={}
    def capture_bbox(renderer,*a,**kw):
        bounds=tight_method(renderer,*a,**kw)
        captured['bbox']=bounds.frozen()
        return bounds
    f.get_tightbbox=capture_bbox
    f.savefig(BytesIO(),format='svg',bbox_inches='tight',pad_inches=.035)
    f.get_tightbbox=tight_method
    old_bbox=captured['bbox']
    f.canvas.draw()
    renderer=f.canvas.get_renderer()
    old_bbox_display=old_bbox.transformed(f.dpi_scale_trans)
    titles=[]
    for ax in f.axes:
        text=ax.title.get_text()
        assert text.startswith('('),text
        font=copy.copy(ax.title.get_fontproperties())
        titles.append((ax,text,font))
        ax.set_title('')
    labels=[]
    for ax,text,font in titles:
        pos=ax.get_position()
        labels.append(f.text((pos.x0+pos.x1)/2,old_bbox.y0/f.get_figheight(),text,
                            ha='center',va='bottom',fontproperties=font))
    f.canvas.draw()
    renderer=f.canvas.get_renderer()
    caption_height=max(label.get_window_extent(renderer).height for label in labels)
    # Include a 2 pt gap below the existing tick labels / axis captions.
    shift=(max(label.get_window_extent(renderer).y1 for label in labels)+2*f.dpi/72-min(ax.xaxis.get_tightbbox(renderer).y0 for ax in f.axes))/(f.get_figheight()*f.dpi)
    top_cap=min((leg.get_window_extent(renderer).y0-2*f.dpi/72)/(f.get_figheight()*f.dpi) for leg in f.legends) if f.legends else 1.0
    for ax in f.axes:
        pos=ax.get_position()
        new_top=min(pos.y1+shift,top_cap)
        ax.set_position([pos.x0,pos.y0+shift,pos.width,new_top-pos.y0-shift])
    f.canvas.draw()
    renderer=f.canvas.get_renderer()
    caps=[label.get_window_extent(renderer) for label in labels]
    axis_bottoms=[ax.xaxis.get_tightbbox(renderer).y0 for ax in f.axes]
    assert min(axis_bottoms)-max(b.y1 for b in caps) >= 1.5*f.dpi/72
    assert max(b.y0 for b in caps)-min(b.y0 for b in caps)<.01
    all_bounds=[ax.get_tightbbox(renderer) for ax in f.axes]+caps
    if f.legends:
        all_bounds += [x.get_window_extent(renderer) for x in f.legends]
        legend_bottom=min(x.get_window_extent(renderer).y0 for x in f.legends)
        plot_top=max(ax.get_window_extent(renderer).y1 for ax in f.axes)
        assert legend_bottom-plot_top>1.5*f.dpi/72,(name,legend_bottom,plot_top)
    assert all(b.x0>=old_bbox_display.x0-1.5 and b.y0>=old_bbox_display.y0-.1 and b.x1<=old_bbox_display.x1+1.5 and b.y1<=old_bbox_display.y1+.1 for b in all_bounds),(name,'out of original crop')
    LAYOUT.append(dict(language=FIG.name,figure=name,panel_titles=[x[1] for x in titles],
                       axes_shift_points=shift*f.get_figheight()*72,
                       min_caption_gap_points=(min(axis_bottoms)-max(b.y1 for b in caps))*72/f.dpi,
                       caption_baselines_aligned=True,original_crop_retained=True))
    # Explicit bbox includes the same .035-inch padding used in the original.
    for ext in ['pdf','svg','png']:
        f.savefig(FIG/(name+'.'+ext),dpi=300,bbox_inches=old_bbox.padded(.035))
    plt.close(f)


def val(phase,case,m,metric='mae'):
    r=[q for q in R[phase] if q['case']==case and q['method']==m];assert r,(phase,case,m);v=np.array([q[metric] for q in r],float)
    DATA.append(dict(phase=phase,case=case,method=m,metric=metric,n=len(v),mean=float(v.mean()),sd=float(v.std(ddof=1)),se=float(v.std(ddof=1)/np.sqrt(len(v)))))
    return v.mean(),v.std(ddof=1)/np.sqrt(len(v))

def canvas(n,width=7.16,height=1.95):
    f,axs=plt.subplots(1,n,figsize=(width,height));axs=np.atleast_1d(axs)
    f.subplots_adjust(left=.075 if n==2 else .055,right=.987,bottom=.25,top=.73,wspace=.52 if n==2 else .46)
    return f,axs

def legend(f,axs,ncol=4):
    h,l=axs[0].get_legend_handles_labels();f.legend(h,l,loc='upper center',bbox_to_anchor=(.5,1.015),ncol=ncol,columnspacing=.8,handlelength=1.65,frameon=False)

def line(ax,phase,cases,x,methods,metric='mae',log=True):
    for m in methods:
        v=[val(phase,c,m,metric) for c in cases];co,mark,style=P[m];ax.errorbar(x,[z[0] for z in v],yerr=[z[1] for z in v],color=co,marker=mark,linestyle=style,label=m,capsize=1.3,elinewidth=.6)
    if log:ax.set_yscale('log')
    ax.grid(axis='y',alpha=.22,lw=.5);ax.set_ylabel('MAE (norm.)' if metric=='mae' else 'Worst-32 MAE')

def synthetic():
    f,a=canvas(4);ms=['ModeSet','JointTemplate','WarmJoint','ContrastKNN','AuditTV']
    line(a[0],'main',[dict(ds='syn',scene=s,p=0.) for s in ['seen','unseen','sync']],range(3),ms);a[0].set_xticks(range(3),['Seen','Unseen','Sync']);a[0].set_title('(a) Composition transfer')
    line(a[1],'main',[dict(ds='syn',scene=s,p=0.) for s in ['seen','unseen','sync']],range(3),ms,'worst32');a[1].set_xticks(range(3),['Seen','Unseen','Sync']);a[1].set_title('(b) Burst error')
    line(a[2],'main',[dict(ds='syn',scene='unseen',p=p) for p in [0.,.05,.25]],[0,.05,.25],ms);a[2].set_xlabel('Test reference probability');a[2].set_xticks([0,.1,.25]);a[2].set_title('(c) Reference reuse')
    line(a[3],'main',[dict(ds='syn',scene=s,p=p) for s,p in [('clean',.25),('unseen',0.)]],range(2),ms);a[3].set_xticks(range(2),['Clean','Attack']);a[3].set_title('(d) Operating conditions');legend(f,a,5);save(f,'synthetic')

def air():
    f,a=canvas(4);ms=['ModeSet','MDM-core','WarmJoint','StableJoint','ContrastKNN','AuditTV']
    for j,ds in enumerate(['air_hold1','air_hold2','air_hold3']):
        line(a[j],'main',[dict(ds=ds,scene='unseen',p=p) for p in [0.,.25]],[0,.25],ms,log=False);a[j].set_xlabel('Test reference probability');a[j].set_xticks([0,.25]);a[j].set_ylim(bottom=0);a[j].set_title(f'({chr(97+j)}) Air window {j+1}')
    for m in ms:
        z=[val('main',dict(ds=d,scene='unseen',p=0.),m) for d in ['air_hold1','air_hold2','air_hold3']];co,mark,style=P[m];a[3].plot(range(3),[q[0] for q in z],color=co,marker=mark,linestyle=style)
    a[3].set_xticks(range(3),['W1','W2','W3']);a[3].set_ylim(bottom=0);a[3].set_ylabel('MAE (norm.)');a[3].set_title('(d) No new reference');legend(f,a,6);save(f,'air')

def budgets():
    f,a=canvas(2,3.5,1.9);ms=['ModeSet','JointTemplate','ContrastKNN','AuditTV']
    ps=[0.,.01,.05,.1,.25,.5];line(a[0],'sweep',[dict(ds='syn',scene='unseen',p=p) for p in ps],ps,ms);a[0].set_xticks([0,.25,.5]);a[0].set_xlabel('Test reference probability');a[0].set_title('(a) Post-learning budget')
    ps=[.05,.1,.25,.5];line(a[1],'sweep',[dict(ds='extended',N=16,K=2,p=0.,learn_p=p) for p in ps],ps,ms);a[1].set_xticks([.05,.25,.5]);a[1].set_xlabel('Learning reference probability');a[1].set_title('(b) Learning budget');legend(f,a,2);save(f,'budgets')

def conditions():
    f,a=canvas(4);ms=['ModeSet','MDM-core','BoxMode','WarmJoint','ContrastKNN','AuditTV'];base=dict(ds='syn',scene='unseen',p=.25)
    jj=[0.,.05,.1,.2,.35,.5];line(a[0],'conditions',[{**base,'jitter':v} for v in jj],jj,ms);a[0].set_xlabel('Relative amplitude jitter');a[0].set_xticks([0,.25,.5]);a[0].set_title('(a) Approximate states')
    dr=[.03,.06,.12,.24];line(a[1],'conditions',[{**base,'drift':v} for v in dr],dr,ms);a[1].set_xlabel('Device-drift amplitude');a[1].set_xticks([.03,.12,.24]);a[1].set_title('(b) Response drift')
    nn=[2,6,12];line(a[2],'conditions',[{**base,'p':0.,'novel':v} for v in nn],nn,ms);a[2].set_xlabel('Sources with new amplitude');a[2].set_xticks(nn);a[2].set_title('(c) Reference interruption')
    for m in ['ModeSet','BoxMode']:
        vals=[val('conditions',{**base,'jitter':v},m,'coverage') for v in jj];co,mark,style=P[m];a[3].errorbar(jj,[v[0] for v in vals],yerr=[v[1] for v in vals],color=co,marker=mark,ls=style,capsize=1.3)
    a[3].set_ylim(0,1.05);a[3].set_xticks([0,.25,.5]);a[3].set_ylabel('Empirical hull containment');a[3].set_xlabel('Relative amplitude jitter');a[3].set_title('(d) Set calibration');legend(f,a,6);save(f,'conditions')

def scale():
    f,a=canvas(2,3.5,1.85);ns=[8,16,32,64];ms=['ModeSet','JointTemplate','ContrastKNN','AuditTV']
    line(a[0],'sweep',[dict(ds='extended',N=n,K=2,p=0.) for n in ns],ns,ms);a[0].set_xscale('log',base=2);a[0].set_xticks(ns,[str(n) for n in ns]);a[0].set_xlabel('Number of sources');a[0].set_title('(a) Recovery scale')
    b=json.loads((BASE/'benchmark.json').read_text())['rows']
    for m in ms:
        vals=[next(r['median_ms'] for r in b if r['N']==n and r['method']==m) for n in ns];co,mark,style=P[m];a[1].plot(ns,vals,color=co,marker=mark,ls=style)
    a[1].set_yscale('log');a[1].set_xscale('log',base=2);a[1].set_xticks(ns,[str(n) for n in ns]);a[1].set_xlabel('Number of sources');a[1].set_ylabel('Median query time (ms)');a[1].set_title('(b) CPU inference');legend(f,a,2);save(f,'scale')

def gas():
    f,a=canvas(2,3.5,1.85);ms=['ModeSet','MDM-core','ContrastKNN','AuditTV']
    for j,b in enumerate([3,7]):
        line(a[j],'conditions',[dict(ds='gas'+str(b),scene='unseen',p=p) for p in [0.,.25]],[0,.25],ms,log=False);a[j].set_ylim(bottom=0);a[j].set_xticks([0,.25]);a[j].set_xlabel('Test reference probability');a[j].set_title(f'({chr(97+j)}) Gas batch {b}')
    legend(f,a,2);save(f,'gas')


ABLATION_STYLE={'ModeSet':('#0B5CAD','o','-'),'MDM-core':('#7C3F99','s','--'),'JointTemplate':('#AF7921','^','-.'),'ContrastKNN':('#505C68','P','-.')}
def ablation(zh=False):
    f,a=plt.subplots(1,2,figsize=(3.5,1.85))
    f.subplots_adjust(left=.075,right=.987,bottom=.25,top=.73,wspace=.52)
    methods=['ModeSet','MDM-core','JointTemplate']
    for i,m in enumerate(methods):
        mean,se=val('main',dict(ds='syn',scene='unseen',p=0.),m)
        a[0].bar(i,mean,yerr=se,color=ABLATION_STYLE[m][0],width=.62,capsize=2)
    a[0].set_yscale('log');a[0].set_xticks(range(3),['ModeSet','MDM','Joint'],rotation=35,ha='right')
    a[0].set_ylabel('MAE（归一化）' if zh else 'MAE (norm.)')
    a[0].set_title('(a) 恢复对照' if zh else '(a) Recovery controls')
    for m,(color,mark,style) in ABLATION_STYLE.items():
        vals=[val('sweep',dict(ds='extended',N=16,K=k,p=0.),m) for k in [2,3,5]]
        a[1].errorbar([2,3,5],[v[0] for v in vals],yerr=[v[1] for v in vals],color=color,marker=mark,linestyle=style,label=m,capsize=1.3,elinewidth=.6)
    a[1].set_yscale('log');a[1].grid(axis='y',alpha=.22,lw=.5)
    a[1].set_ylabel('MAE（归一化）' if zh else 'MAE (norm.)')
    a[1].set_xticks([2,3,5]);a[1].set_xlabel('每个受控来源的状态数' if zh else 'States per controlled source')
    a[1].set_title('(b) 字母表大小' if zh else '(b) Alphabet size')
    h,l=a[1].get_legend_handles_labels();f.legend(h,l,loc='upper center',bbox_to_anchor=(.5,1.025),ncol=2,frameon=False)
    save(f,'ablation')



if __name__=='__main__':
    if args.language in ['zh','both']:
        if args.font_dir is not None:
            for font_file in sorted(args.font_dir.iterdir()):
                if font_file.suffix.lower() in ['.ttf','.otf']:
                    font_manager.fontManager.addfont(str(font_file))
        for candidate in ['Microsoft YaHei','Noto Sans CJK SC','Noto Sans SC','WenQuanYi Zen Hei']:
            try:
                font_manager.findfont(candidate,fallback_to_default=False)
                ZH_FONT=candidate
                break
            except ValueError:
                pass
        else:
            parser.error('Chinese output requires Microsoft YaHei, Noto Sans CJK SC, Noto Sans SC, or WenQuanYi Zen Hei. Install a font or use --font-dir. English output needs no Chinese font.')
    style(False)
    for fn in [synthetic,budgets,ablation,air,gas,conditions,scale]:
        if fn is ablation and args.language=='zh':
            style(True);ablation(True);style(False)
        else:
            fn()
    if args.language=='both':
        import shutil
        en=FIG;FIG=args.output/'zh';FIG.mkdir(parents=True,exist_ok=True)
        # These six figures used English text in the Chinese manuscript.
        for name in ['synthetic','budgets','air','gas','conditions','scale']:
            for ext in ['pdf','svg','png']:
                shutil.copy2(en/(name+'.'+ext),FIG/(name+'.'+ext))
        style(True);ablation(True)
    (args.output/'source_data.json').write_text(json.dumps(DATA,ensure_ascii=False,indent=2),encoding='utf-8')
    (args.output/'layout_checks.json').write_text(json.dumps(LAYOUT,ensure_ascii=False,indent=2),encoding='utf-8')
    print('Figures 5--11 rendered; original crops, labels and frozen data retained.')


